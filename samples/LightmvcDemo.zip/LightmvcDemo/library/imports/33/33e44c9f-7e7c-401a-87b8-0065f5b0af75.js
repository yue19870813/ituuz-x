"use strict";
cc._RF.push(module, '33e44yffnxAGoe4AGX1sK91', 'BaseView');
// libs/core/mvc/base/BaseView.ts

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 视图基类
 * @author ituuz
 */
var ViewEvent_1 = require("./ViewEvent");
var ViewManager_1 = require("../manager/ViewManager");
var UIUtils_1 = require("../../util/UIUtils");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var BaseView = /** @class */ (function (_super) {
    __extends(BaseView, _super);
    function BaseView() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    BaseView.prototype.__init__ = function () {
        this.__event__ = new ViewEvent_1.default();
        this.ui = UIUtils_1.default.seekAllSubView(this.node);
        this.init();
    };
    /**
     * view 创建时会被调用，子类可以重写.
     */
    BaseView.prototype.init = function () {
    };
    /**
     * 发送UI事件
     * @param {string} event 事件名称
     * @param {Object} body 事件参数
     */
    BaseView.prototype.sendEvent = function (event, body) {
        this.__event__.emit(event, body);
    };
    /**
     * 绑定UI事件
     * @param {string} name 事件名称
     * @param {(body: any)=>void} cb 事件回调
     * @param {BaseMediator} target 事件回调绑定对象
     * @private 私有函数，不得调用。
     */
    BaseView.prototype.__bindEvent__ = function (name, cb, target) {
        this.__event__.on(name, cb, target);
    };
    /**
     * 关闭当前的界面
     */
    BaseView.prototype.closeView = function () {
        ViewManager_1.ViewManager.getInstance().__closeView__(this);
        this.__onClose__();
    };
    /**
     * 关闭所有弹出的界面
     */
    BaseView.prototype.closeAllPopView = function () {
        ViewManager_1.ViewManager.getInstance().__closeAllPopView__();
    };
    BaseView.prototype.__onClose__ = function () {
        this.__event__.destroy();
        this.onClose();
        this.node.destroy();
    };
    /**
     * 当界面被关闭时会被调用，子类可以重写该方法。
     * @override
     */
    BaseView.prototype.onClose = function () {
    };
    /**
     * 子类覆盖，返回UI的prefab路径
     * @return {string}
     */
    BaseView.path = function () {
        return "";
    };
    BaseView = __decorate([
        ccclass
    ], BaseView);
    return BaseView;
}(cc.Component));
exports.BaseView = BaseView;

cc._RF.pop();