"use strict";
cc._RF.push(module, 'e2d9egP1DZJpK7Q5gaA+uGv', 'ITMapPos');
// libs/extension/path/ITMapPos.ts

Object.defineProperty(exports, "__esModule", { value: true });
/** 地图格子状态枚举 */
var ITMapPosStatus;
(function (ITMapPosStatus) {
    ITMapPosStatus[ITMapPosStatus["CAN_NOT_MOVE"] = 0] = "CAN_NOT_MOVE";
    ITMapPosStatus[ITMapPosStatus["CAN_MOVE"] = 1] = "CAN_MOVE"; // 可移动
})(ITMapPosStatus = exports.ITMapPosStatus || (exports.ITMapPosStatus = {}));
/** 地图坐标对象 */
var ITMapPos = /** @class */ (function () {
    function ITMapPos(x, y, limit, s) {
        this.status = ITMapPosStatus.CAN_NOT_MOVE; // 0: 不能移动， 1: 可移动
        this.limit = 0; // 当前点的剩余行动力
        this.x = x;
        this.y = y;
        if (s)
            this.status = s;
        if (limit)
            this.limit = limit;
    }
    ITMapPos.prototype.compare = function (map) {
    };
    /** 转成cc.Vec2 */
    ITMapPos.prototype.toVec2 = function () {
        return cc.v2(this.x, this.y);
    };
    return ITMapPos;
}());
exports.default = ITMapPos;

cc._RF.pop();