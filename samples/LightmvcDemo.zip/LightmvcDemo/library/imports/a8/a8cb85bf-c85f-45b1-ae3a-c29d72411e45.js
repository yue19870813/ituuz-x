"use strict";
cc._RF.push(module, 'a8cb8W/yF9Fsa46wp1yQR5F', 'FrameworkCfg');
// libs/FrameworkCfg.ts

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 框架配置，通过init接口初始化这些配置。
 */
var FrameworkCfg = /** @class */ (function () {
    function FrameworkCfg() {
    }
    /** 是否是测试环境 */
    FrameworkCfg.DEBUG = false;
    /** 默认的设计分辨率 */
    FrameworkCfg.DESIGN_RESOLUTION = cc.size(640, 960);
    /** 是否高适配 */
    FrameworkCfg.FIT_HEIGHT = true;
    /** 是否宽适配 */
    FrameworkCfg.FIT_WIDTH = false;
    return FrameworkCfg;
}());
exports.default = FrameworkCfg;

cc._RF.pop();