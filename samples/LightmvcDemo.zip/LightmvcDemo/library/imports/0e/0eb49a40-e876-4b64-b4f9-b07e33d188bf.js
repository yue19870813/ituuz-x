"use strict";
cc._RF.push(module, '0eb49pA6HZLZLT5sH4z0Yi/', 'TreeNode');
// libs/core/data_structure/tree/TreeNode.ts

Object.defineProperty(exports, "__esModule", { value: true });
var TreeNode = /** @class */ (function () {
    function TreeNode(data) {
    }
    return TreeNode;
}());
exports.default = TreeNode;

cc._RF.pop();