"use strict";
cc._RF.push(module, 'eb3858D0dRHD6IJ7jVBtPx6', 'GameView');
// libs/mvc_ex/base/GameView.ts

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 游戏UI view层的基类
 * @author ituuz
 * @example
 * // 子类重写该函数来实现图集的自动加载和释放
 * public atlasName(): string[] {
 *   return [
 *      "atlasPath1",
 *      "atlasPath2"
 *   ];
 * }
 * // 使用如下接口来为sprite设置纹理
 * setSpriteFrame(sprite, "atlasPath1");
 */
var BaseView_1 = require("../../core/mvc/base/BaseView");
var ITAtlas_1 = require("../../core/load/atlas/ITAtlas");
var AtlasManager_1 = require("../../core/load/atlas/AtlasManager");
var GameView = /** @class */ (function (_super) {
    __extends(GameView, _super);
    function GameView() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /** @override */
    GameView.prototype.__init__ = function () {
        _super.prototype.__init__.call(this);
        this.loadAtlas();
    };
    /** 开始加载atlas */
    GameView.prototype.loadAtlas = function () {
        this._uiAtlas = new ITAtlas_1.default();
        var atlasList = this.atlasName();
        for (var _i = 0, atlasList_1 = atlasList; _i < atlasList_1.length; _i++) {
            var atlas = atlasList_1[_i];
            // 通过AtlasManager加载图集纹理资源，并返回图集引用；
            var itAtlas = AtlasManager_1.default.loadAtlas(atlas);
            // 将图集引用添加到当前UI对象中，方便使用。
            this._uiAtlas.addAtlas(atlas, itAtlas);
        }
    };
    /**
     * 为sprite设置纹理
     * @param {cc.Sprite} sprite sprite对象
     * @param {string} name 纹理名称
     * @param {string} key 图集key值，如果不传key，则默认使用该UI的第一个图集来设置；
     */
    GameView.prototype.setSpriteFrame = function (sprite, name, key) {
        this._uiAtlas.setSpriteFrame(sprite, name, key);
    };
    /**
     * 子类重写来实现资源的加载和释放
     */
    GameView.prototype.atlasName = function () {
        return [];
    };
    /** @override */
    GameView.prototype.onClose = function () {
        var atlasMap = this._uiAtlas.atlasMap;
        var keys = atlasMap.keys();
        var keyList = Array.from(keys);
        for (var _i = 0, keyList_1 = keyList; _i < keyList_1.length; _i++) {
            var k = keyList_1[_i];
            AtlasManager_1.default.releaseAtlas(k);
        }
    };
    return GameView;
}(BaseView_1.BaseView));
exports.default = GameView;

cc._RF.pop();