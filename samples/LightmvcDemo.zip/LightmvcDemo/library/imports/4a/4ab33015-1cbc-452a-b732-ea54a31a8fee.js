"use strict";
cc._RF.push(module, '4ab33AVHLxFKrcy6lSjGo/u', 'SceneCfg');
// script/SceneCfg.ts

Object.defineProperty(exports, "__esModule", { value: true });
var SceneCfg = /** @class */ (function () {
    function SceneCfg() {
    }
    SceneCfg.DEFAULT_SCENE = {
        viewClass: "DefaultScene",
        medClass: "DefaultSceneMediator",
        children: [
            {
                viewClass: "TopView",
                medClass: "TopMediator",
                children: []
            },
            {
                viewClass: "FirstView",
                medClass: "FirstMediator",
                children: []
            }
        ]
    };
    SceneCfg.SECOND_SCENE = {
        viewClass: "SecondScene",
        medClass: "SecondSceneMediator",
        children: [
            {
                viewClass: "SecondView",
                medClass: "SecondMediator",
                children: []
            }
        ]
    };
    return SceneCfg;
}());
exports.default = SceneCfg;
var ViewCfg = /** @class */ (function () {
    function ViewCfg() {
    }
    ViewCfg.POP_A_VIEW = {
        viewClass: "PopAView",
        medClass: "PopAMediator",
        children: []
    };
    ViewCfg.POP_B_VIEW = {
        viewClass: "PopBView",
        medClass: "PopBMediator",
        children: []
    };
    return ViewCfg;
}());
exports.ViewCfg = ViewCfg;

cc._RF.pop();