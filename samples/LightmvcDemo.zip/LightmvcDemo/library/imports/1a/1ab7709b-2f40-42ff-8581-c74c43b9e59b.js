"use strict";
cc._RF.push(module, '1ab77CbL0BC/4WBx0xDueWb', 'PlayerCommand');
// script/command/PlayerCommand.ts

Object.defineProperty(exports, "__esModule", { value: true });
var SimpleCommand_1 = require("../../libs/lightMVC/core/command/SimpleCommand");
var PlayerModel_1 = require("../model/PlayerModel");
/**
 * 更新经验命令
 */
var UpdateExpCommand = /** @class */ (function (_super) {
    __extends(UpdateExpCommand, _super);
    function UpdateExpCommand() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    UpdateExpCommand.prototype.execute = function (body) {
        var model = this.getModel(PlayerModel_1.default);
        model.setPlayerExp(Number(body));
    };
    UpdateExpCommand.prototype.undo = function (body) {
        var model = this.getModel(PlayerModel_1.default);
        var player = model.getPlayer();
        player.exp = player.exp - Number(body);
    };
    return UpdateExpCommand;
}(SimpleCommand_1.default));
exports.UpdateExpCommand = UpdateExpCommand;

cc._RF.pop();