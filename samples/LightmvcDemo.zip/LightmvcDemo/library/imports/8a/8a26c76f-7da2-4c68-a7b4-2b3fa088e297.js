"use strict";
cc._RF.push(module, '8a26cdvfaJMaKe0Kz+giOKX', 'BaseMediator');
// libs/core/mvc/base/BaseMediator.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Facade_1 = require("../Facade");
var NotificationManager_1 = require("../manager/NotificationManager");
var CommandManager_1 = require("../manager/CommandManager");
/**
 * 视图中介者基类
 * @author ituuz
 * @description 生命周期
 *      BaseMediator.init
 *      BaseView.__init__
 *      BaseMediator.viewDidAppear
 */
var BaseMediator = /** @class */ (function () {
    function BaseMediator() {
    }
    /**
     * 内部初始化使用，外部不要调用。
     * @private
     */
    BaseMediator.prototype.__init__ = function () {
        this._notiMap = new Map();
    };
    /**
     * 绑定UI事件，接收view层派发的事件。
     * @param {string} name 事件名称
     * @param {(any)=>void} cb 事件回调
     * @param {BaseMediator} target 回调绑定对象
     */
    BaseMediator.prototype.bindEvent = function (name, cb, target) {
        this.view.__bindEvent__(name, cb, target);
    };
    /**
     * 注册消息监听
     * @param {string} noti 通知key值
     * @param {(data: any)=>void} cb 通知监听的回调函数
     * @param {Object} target 回调绑定的对象
     */
    BaseMediator.prototype.registerNoti = function (noti, cb, target) {
        this._notiMap.set(noti, { key: noti, cb: cb, target: target });
    };
    /**
     * 发送消息通知
     * @param {string} noti 通知key值
     * @param {Object} body 消息传递的参数
     */
    BaseMediator.prototype.sendNoti = function (noti, body) {
        NotificationManager_1.default.getInstance().__sendNotification__(noti, body);
    };
    /**
     * 发送命令接口
     * @param {{new (): BaseCommand}} cmd 命令类
     * @param {Object} data 命令参数
     */
    BaseMediator.prototype.sendCmd = function (cmd, data) {
        CommandManager_1.default.getInstance().__executeCommand__(cmd, data);
    };
    /**
     * 打开新场景
     * @param mediator
     * @param view
     * @param data {Object} data 自定义的任意类型透传数据。（可选）
     */
    BaseMediator.prototype.runScene = function (mediator, view, data) {
        Facade_1.Facade.getInstance().runScene(mediator, view, data);
    };
    /**
     * 返回上一场景
     * @returns {boolean}是否存在上一个场景
     */
    BaseMediator.prototype.backScene = function () {
        return Facade_1.Facade.getInstance().backScene();
    };
    /**
     * 打开view界面
     * @param {{new(): BaseMediator}} mediator 界面mediator类型，类类型。
     * @param {{new(): BaseView}} view view 场景mediator类型，类类型。
     * @param {Object} data 自定义的任意类型透传数据。（可选）
     */
    BaseMediator.prototype.popView = function (mediator, view, data) {
        Facade_1.Facade.getInstance().popView(mediator, view, data);
    };
    /**
     * 添加层级
     * @param {{new(): BaseMediator}} mediator 界面mediator类型，类类型。
     * @param {{new(): BaseView}} view view 场景mediator类型，类类型。
     * @param {number} zOrder 层级。（可选）
     * @param {Object} data 自定义的任意类型透传数据。（可选）
     */
    BaseMediator.prototype.addLayer = function (mediator, view, zOrder, data) {
        Facade_1.Facade.getInstance().addLayer(mediator, view, zOrder, data);
    };
    /**
     * 获取model对象
     * @param {{new (): BaseModel}} model
     */
    BaseMediator.prototype.getModel = function (model) {
        return Facade_1.Facade.getInstance().getModel(model);
    };
    return BaseMediator;
}());
exports.default = BaseMediator;

cc._RF.pop();