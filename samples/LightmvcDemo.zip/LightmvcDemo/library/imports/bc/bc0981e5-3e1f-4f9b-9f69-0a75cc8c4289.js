"use strict";
cc._RF.push(module, 'bc098HlPh9Pm59pCnXMjEKJ', 'SecondScene');
// script/view/SecondScene.ts

Object.defineProperty(exports, "__esModule", { value: true });
var GameScene_1 = require("../../libs/mvc_ex/base/GameScene");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SecondScene = /** @class */ (function (_super) {
    __extends(SecondScene, _super);
    function SecondScene() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SecondScene = __decorate([
        ccclass
    ], SecondScene);
    return SecondScene;
}(GameScene_1.default));
exports.default = SecondScene;

cc._RF.pop();