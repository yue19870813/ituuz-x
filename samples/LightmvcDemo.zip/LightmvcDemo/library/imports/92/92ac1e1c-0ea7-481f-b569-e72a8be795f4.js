"use strict";
cc._RF.push(module, '92ac14cDqdIH7Vp5yqL55X0', 'PrefabLoader');
// libs/core/load/loader/base/PrefabLoader.ts

Object.defineProperty(exports, "__esModule", { value: true });
var BaseLoader_1 = require("./BaseLoader");
var PrefabLoader = /** @class */ (function (_super) {
    __extends(PrefabLoader, _super);
    function PrefabLoader() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    PrefabLoader.prototype.loadNetRes = function (path, type, callback) {
        // TODO 加载网络预制体资源
        throw new Error("PrefabLoader loadNetRes method not implemented.");
    };
    PrefabLoader.prototype.loadRemoteRes = function (path, type, callback) {
        // TODO 加载远程待下载预制体资源
        throw new Error("PrefabLoader loadRemoteRes method not implemented.");
    };
    PrefabLoader.prototype.loadLocalRes = function (path, type, callback) {
        cc.loader.loadRes(path, type, callback);
    };
    return PrefabLoader;
}(BaseLoader_1.default));
exports.default = PrefabLoader;

cc._RF.pop();