"use strict";
cc._RF.push(module, '922ccWf0WlASp4p6I29nz83', 'AtlasLoader');
// libs/core/load/loader/base/AtlasLoader.ts

Object.defineProperty(exports, "__esModule", { value: true });
var BaseLoader_1 = require("./BaseLoader");
var AtlasLoader = /** @class */ (function (_super) {
    __extends(AtlasLoader, _super);
    function AtlasLoader() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    AtlasLoader.prototype.loadNetRes = function (path, type, callback) {
        // TODO 加载网络图集资源
        throw new Error("AtlasLoader loadNetRes method not implemented.");
    };
    AtlasLoader.prototype.loadRemoteRes = function (path, type, callback) {
        // TODO 加载远程待下载图集资源
        throw new Error("AtlasLoader loadRemoteRes method not implemented.");
    };
    AtlasLoader.prototype.loadLocalRes = function (path, type, callback) {
        cc.loader.loadRes(path, type, callback);
    };
    return AtlasLoader;
}(BaseLoader_1.default));
exports.default = AtlasLoader;

cc._RF.pop();