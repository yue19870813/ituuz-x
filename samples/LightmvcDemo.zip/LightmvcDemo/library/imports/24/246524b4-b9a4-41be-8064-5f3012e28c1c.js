"use strict";
cc._RF.push(module, '24652S0uaRBvoBkXzAS4owc', 'LoadLayersCmd');
// libs/mvc_ex/command/LoadLayersCmd.ts

Object.defineProperty(exports, "__esModule", { value: true });
var SimpleCommand_1 = require("../../core/mvc/command/SimpleCommand");
var Facade_1 = require("../../core/mvc/Facade");
var JSUtil_1 = require("../../core/util/JSUtil");
var GameScene_1 = require("../base/GameScene");
/**
 * 根据配置加载场景或者view的命令。
 * @author ituuz
 */
var LoadLayersCmd = /** @class */ (function (_super) {
    __extends(LoadLayersCmd, _super);
    function LoadLayersCmd() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    LoadLayersCmd.prototype.undo = function (body) {
        throw new Error("Method not implemented.");
    };
    LoadLayersCmd.prototype.execute = function (body) {
        var _this = this;
        var mvc = body.mvc;
        var data = body.data;
        // 加载完场景开始加载view
        var loadViewChildren = function (isRoot) {
            if (isRoot === void 0) { isRoot = true; }
            if (!isRoot) {
                _this.loadViews([mvc]);
            }
            else {
                _this.loadViews(mvc.children, mvc.medClass);
            }
        };
        var viewModule = null;
        // 根据配置文件开始加载
        JSUtil_1.default.importCls(mvc.viewClass).then(function (module) {
            viewModule = module;
            return JSUtil_1.default.importCls(mvc.medClass);
        }).then(function (medModule) {
            if (JSUtil_1.default.isChildClassOf(viewModule, GameScene_1.default)) {
                Facade_1.Facade.getInstance().runScene(medModule, viewModule, data, loadViewChildren.bind(_this));
            }
            else {
                loadViewChildren(false);
            }
        });
    };
    /** 根据配置数据加载view */
    LoadLayersCmd.prototype.loadViews = function (views, parent, isRoot) {
        var _this = this;
        if (parent === void 0) { parent = ""; }
        if (isRoot === void 0) { isRoot = false; }
        if (views && views.length > 0) {
            // 获取父节点
            var parentNode_1 = null;
            if (isRoot) {
                var scene = Facade_1.Facade.getInstance().getCurScene();
                parentNode_1 = scene.view.node;
            }
            else {
                var layerList = Facade_1.Facade.getInstance().getLayerList();
                for (var _i = 0, layerList_1 = layerList; _i < layerList_1.length; _i++) {
                    var layer = layerList_1[_i];
                    var layerName = layer["__proto__"]["constructor"]["name"];
                    if (layerName == parent) {
                        parentNode_1 = layer.view.node;
                        break;
                    }
                }
            }
            var _loop_1 = function (i) {
                var mvcObj = views[i];
                var viewModule = null;
                JSUtil_1.default.importCls(mvcObj.viewClass).then(function (module) {
                    viewModule = module;
                    return JSUtil_1.default.importCls(mvcObj.medClass);
                }).then(function (medModule) {
                    Facade_1.Facade.getInstance().addLayer(medModule, viewModule, i, null, function () {
                        // 加载完成后的回调,递归加载childern
                        if (mvcObj.children && mvcObj.children.length > 0) {
                            _this.loadViews(mvcObj.children, mvcObj.medClass, false);
                        }
                    }, parentNode_1);
                });
            };
            // 遍历节点数组创建layer
            for (var i = 0; i < views.length; i++) {
                _loop_1(i);
            }
        }
    };
    return LoadLayersCmd;
}(SimpleCommand_1.default));
exports.default = LoadLayersCmd;

cc._RF.pop();