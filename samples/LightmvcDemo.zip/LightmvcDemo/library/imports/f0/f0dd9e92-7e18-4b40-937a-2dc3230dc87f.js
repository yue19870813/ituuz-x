"use strict";
cc._RF.push(module, 'f0dd96SfhhLQJN6LcMjDch/', 'ConfigBase');
// libs/core/load/config/ConfigBase.ts

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 静态数据加载基类
 * @author ituuz
 */
var ConfigBase = /** @class */ (function () {
    function ConfigBase() {
    }
    /**
     * @override
     * 加载数据接口, 需要子类重写.
     * @param data 数据
     */
    ConfigBase.loadData = function (data) {
    };
    /**
     * 根据":"分割字符串，返回number数组
     * @param {string} row 字符串
     */
    ConfigBase.parseNumArr = function (row) {
        var res = [];
        var temp = row.split(":");
        for (var _i = 0, temp_1 = temp; _i < temp_1.length; _i++) {
            var v = temp_1[_i];
            res.push(Number(v));
        }
        return res;
    };
    return ConfigBase;
}());
exports.default = ConfigBase;

cc._RF.pop();