"use strict";
cc._RF.push(module, 'b0b6eVk51hIJIbmrhhKxEZg', 'ConfigManager');
// libs/core/load/config/ConfigManager.ts

Object.defineProperty(exports, "__esModule", { value: true });
var SingleBase_1 = require("../../base/SingleBase");
var JSUtil_1 = require("../../util/JSUtil");
var LogUtil_1 = require("../../util/LogUtil");
var ITResourceLoader_1 = require("../loader/ITResourceLoader");
/**
 * 静态数据管理器
 * @author ituuz
 */
var ConfigManager = /** @class */ (function (_super) {
    __extends(ConfigManager, _super);
    function ConfigManager() {
        var _this = _super.call(this) || this;
        // 待加载的总数量
        _this._loadMaxCount = 0;
        // 已经加载完成的数量
        _this._loadCount = 0;
        return _this;
    }
    ConfigManager.getInstance = function () {
        return ConfigManager._instance;
    };
    /**
     * 根据配置列表加载静态数据
     * @param {string[]} configList 配置列表，需要加载的类名。
     * @param {(count: number) => void} progressCallback 加载进度回调
     * @param {() => void} finishedCallback 加载完成回调
     */
    ConfigManager.prototype.loadConfList = function (configList, progressCallback, finishedCallback) {
        this._loadMaxCount = configList.length;
        this._itemLoadCallback = progressCallback;
        this._loadFinishedCallback = finishedCallback;
        this.startLoad(configList);
    };
    /** 开始加载 */
    ConfigManager.prototype.startLoad = function (configList) {
        var _this = this;
        if (configList.length <= 0) {
            return;
        }
        var item = configList.shift();
        ITResourceLoader_1.default.loadRes("config/" + item, cc.TextAsset, function (err, asset) {
            if (err) {
                LogUtil_1.default.warn(err);
            }
            else {
                // 将字符串实例化成对象
                JSUtil_1.default.importCls(item).then(function (cls) {
                    cls.loadData(asset.text);
                    _this._itemLoadCallback && _this._itemLoadCallback(++_this._loadCount);
                    if (_this._loadCount >= _this._loadMaxCount) {
                        _this._loadFinishedCallback && _this._loadFinishedCallback();
                    }
                    _this.startLoad(configList);
                });
            }
        });
    };
    /**
     * 加载一个配置
     * @param {string} name 配置名称，需要加载的类名。
     * @param {() => void} finishedCallback 加载完成回调
     */
    ConfigManager.prototype.loadConfig = function (name, finishedCallback) {
        ITResourceLoader_1.default.loadRes("config/" + name, cc.TextAsset, function (err, asset) {
            if (err) {
                LogUtil_1.default.warn(err);
            }
            else {
                // 将字符串实例化成对象
                JSUtil_1.default.importCls(name).then(function (cls) {
                    cls.loadData(asset.text);
                    finishedCallback && finishedCallback();
                });
            }
        });
    };
    /**
     * 释放指定配置
     * @param {string} name 配置名称，需要释放的类名。
     */
    ConfigManager.prototype.releaseConfig = function (name) {
        // 将字符串实例化成对象
        JSUtil_1.default.importCls(name).then(function (cls) {
            cls["_itemDataList"] = null;
            cls["_itemDataMap"] = null;
        });
    };
    ConfigManager._instance = new ConfigManager();
    return ConfigManager;
}(SingleBase_1.default));
exports.default = ConfigManager;
// 将接口导出
window.it || (window.it = {});
window.it.ConfigManager = ConfigManager;

cc._RF.pop();