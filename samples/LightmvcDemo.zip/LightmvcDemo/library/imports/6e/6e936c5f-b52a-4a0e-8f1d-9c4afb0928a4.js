"use strict";
cc._RF.push(module, '6e936xftSpKDo8dnEr7CSik', 'LoadPopViewsCmd');
// libs/mvc_ex/command/LoadPopViewsCmd.ts

Object.defineProperty(exports, "__esModule", { value: true });
var SimpleCommand_1 = require("../../core/mvc/command/SimpleCommand");
var Facade_1 = require("../../core/mvc/Facade");
var JSUtil_1 = require("../../core/util/JSUtil");
/**
 * 根据配置加载场景或者view的命令。
 * @author ituuz
 */
var LoadPopViewsCmd = /** @class */ (function (_super) {
    __extends(LoadPopViewsCmd, _super);
    function LoadPopViewsCmd() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    LoadPopViewsCmd.prototype.undo = function (body) {
        throw new Error("Method not implemented.");
    };
    LoadPopViewsCmd.prototype.execute = function (body) {
        // 增加参数传递逻辑
        this.loadViews([body.mvc], body.data);
    };
    /** 根据配置数据加载view */
    LoadPopViewsCmd.prototype.loadViews = function (views, data) {
        var _this = this;
        if (data === void 0) { data = null; }
        if (views && views.length > 0) {
            var _loop_1 = function (i) {
                var mvcObj = views[i];
                var viewModule = null;
                JSUtil_1.default.importCls(mvcObj.viewClass).then(function (module) {
                    viewModule = module;
                    return JSUtil_1.default.importCls(mvcObj.medClass);
                }).then(function (medModule) {
                    Facade_1.Facade.getInstance().popView(medModule, viewModule, data, function () {
                        // 加载完成后的回调,递归加载childern
                        if (mvcObj.children && mvcObj.children.length > 0) {
                            _this.loadViews(mvcObj.children, null);
                        }
                    });
                });
            };
            // 遍历节点数组创建layer
            for (var i = 0; i < views.length; i++) {
                _loop_1(i);
            }
        }
    };
    return LoadPopViewsCmd;
}(SimpleCommand_1.default));
exports.default = LoadPopViewsCmd;

cc._RF.pop();