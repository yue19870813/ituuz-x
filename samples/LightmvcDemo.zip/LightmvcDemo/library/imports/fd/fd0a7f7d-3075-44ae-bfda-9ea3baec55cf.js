"use strict";
cc._RF.push(module, 'fd0a799MHVErr/anqO67FXP', 'FirstMediator');
// script/view/first/FirstMediator.ts

Object.defineProperty(exports, "__esModule", { value: true });
var FirstView_1 = require("./FirstView");
var GameMediator_1 = require("../../../libs/mvc_ex/base/GameMediator");
var SceneCfg_1 = require("../../SceneCfg");
var FirstMediator = /** @class */ (function (_super) {
    __extends(FirstMediator, _super);
    function FirstMediator() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    FirstMediator.prototype.init = function (data) {
        var _this = this;
        console.log("FirstMediator::init===>>>", data);
        this.view.setData(data);
        this.bindEvent(FirstView_1.default.OPEN_A, function (str) {
            _this.addView(SceneCfg_1.ViewCfg.POP_A_VIEW);
        }, this);
        this.bindEvent(FirstView_1.default.OPEN_B, function (str) {
            _this.addView(SceneCfg_1.ViewCfg.POP_B_VIEW);
        }, this);
    };
    FirstMediator.prototype.viewDidAppear = function () {
    };
    FirstMediator.prototype.destroy = function () {
    };
    return FirstMediator;
}(GameMediator_1.default));
exports.default = FirstMediator;

cc._RF.pop();