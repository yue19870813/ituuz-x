"use strict";
cc._RF.push(module, '967c5GJoUhEgafiZuC0l4iJ', 'Constants');
// libs/core/mvc/Constants.ts

Object.defineProperty(exports, "__esModule", { value: true });
/** 打开view选项枚举 */
var OPEN_VIEW_OPTION;
(function (OPEN_VIEW_OPTION) {
    /** 固定UI层，与其它ui分开管理，需要设置zOrder */
    OPEN_VIEW_OPTION[OPEN_VIEW_OPTION["LAYER"] = 0] = "LAYER";
    /** 叠加在其他view上 */
    OPEN_VIEW_OPTION[OPEN_VIEW_OPTION["OVERLAY"] = 1] = "OVERLAY";
    /** 独立打开，关闭其他view */
    OPEN_VIEW_OPTION[OPEN_VIEW_OPTION["SINGLE"] = 2] = "SINGLE";
})(OPEN_VIEW_OPTION = exports.OPEN_VIEW_OPTION || (exports.OPEN_VIEW_OPTION = {}));

cc._RF.pop();