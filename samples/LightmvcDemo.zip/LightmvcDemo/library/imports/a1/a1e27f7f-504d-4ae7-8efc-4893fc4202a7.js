"use strict";
cc._RF.push(module, 'a1e279/UE1K5478SJP8QgKn', 'JSUtil');
// libs/core/util/JSUtil.ts

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * JSUtil:操作js相关接口.
 * @author ituuz
 * @desc 根据字符串创建对象,判断是否是派生类等接口.
 */
var JSUtil = /** @class */ (function () {
    function JSUtil() {
    }
    /**
     * 根据字符串创建对象
     * @param {string} cls 类的字符串值
     */
    JSUtil.importCls = function (cls) {
        return new Promise(function (resolve, reject) {
            Promise.resolve().then(function () { return require(cls); }).then(function (module) {
                if (module && module.default) {
                    resolve(module.default);
                }
                else {
                    console.error(cls, "中没有default类.");
                    reject(module);
                }
            });
        });
    };
    /**
     * 获取父类
     * @param {Object} ctor 子类类名
     * @return {Object}
     */
    JSUtil.getSuper = function (ctor) {
        var proto = ctor.prototype;
        var dunderProto = proto && Object.getPrototypeOf(proto);
        return dunderProto && dunderProto.constructor;
    };
    /**
     * 判断subclass是否是superclass的子类
     * @param subclass
     * @param superclass
     */
    JSUtil.isChildClassOf = function (subclass, superclass) {
        if (subclass && superclass) {
            if (typeof subclass !== 'function') {
                return false;
            }
            if (typeof superclass !== 'function') {
                return false;
            }
            if (subclass === superclass) {
                return true;
            }
            for (;;) {
                subclass = JSUtil.getSuper(subclass);
                if (!subclass) {
                    return false;
                }
                if (subclass === superclass) {
                    return true;
                }
            }
        }
        return false;
    };
    return JSUtil;
}());
exports.default = JSUtil;

cc._RF.pop();