"use strict";
cc._RF.push(module, '9e1c7mHAitEiYnxNufnqX3X', 'GameScene');
// libs/mvc_ex/base/GameScene.ts

Object.defineProperty(exports, "__esModule", { value: true });
var BaseScene_1 = require("../../core/mvc/base/BaseScene");
var GameScene = /** @class */ (function (_super) {
    __extends(GameScene, _super);
    function GameScene() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return GameScene;
}(BaseScene_1.default));
exports.default = GameScene;

cc._RF.pop();