"use strict";
cc._RF.push(module, '01afafDUMlNRYbF+2N/bwKB', 'SimpleCommand');
// libs/core/mvc/command/SimpleCommand.ts

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 命令基类
 * @author ituuz
 */
var BaseCommand_1 = require("../base/BaseCommand");
var Facade_1 = require("../Facade");
var CommandManager_1 = require("../manager/CommandManager");
var SimpleCommand = /** @class */ (function (_super) {
    __extends(SimpleCommand, _super);
    function SimpleCommand() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /**
     * 获取model对象
     * @param {{new (): BaseModel}} model
     */
    SimpleCommand.prototype.getModel = function (model) {
        return Facade_1.Facade.getInstance().getModel(model);
    };
    /**
     * 执行命令
     * @param {{new (): BaseCommand}} command 命令对象
     * @param {Object} body 命令参数
     */
    SimpleCommand.prototype.sendCmd = function (command, body) {
        CommandManager_1.default.getInstance().__executeCommand__(command, body);
    };
    /**
     * 撤销命令
     * @param {{new (): BaseCommand}} command 命令对象
     * @param {Object} body 命令参数
     */
    SimpleCommand.prototype.undoCmd = function (command, body) {
        Facade_1.Facade.getInstance().__undoCommand__(command, body);
    };
    SimpleCommand.prototype.sendNoti = function () {
    };
    return SimpleCommand;
}(BaseCommand_1.default));
exports.default = SimpleCommand;

cc._RF.pop();