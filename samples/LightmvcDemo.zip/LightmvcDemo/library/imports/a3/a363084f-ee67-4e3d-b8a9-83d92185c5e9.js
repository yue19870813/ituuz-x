"use strict";
cc._RF.push(module, 'a3630hP7mdOPbipg9khhcXp', 'AtlasManager');
// libs/core/load/atlas/AtlasManager.ts

Object.defineProperty(exports, "__esModule", { value: true });
var ITAtlas_1 = require("./ITAtlas");
var LogUtil_1 = require("../../util/LogUtil");
var ITResourceLoader_1 = require("../loader/ITResourceLoader");
/**
 * 图集资源管理类，负责图集加载以及引用计数
 * @author ituuz
 */
var AtlasManager = /** @class */ (function () {
    function AtlasManager() {
    }
    /** 初始化依赖关系 */
    AtlasManager.initDeps = function () {
        // TODO 根据编辑器中的依赖关系，初始化图集引用计数
    };
    /**
     * 加载图集
     * @param {string} path 图集路径
     * @param {(err, atlas) => void} callback 加载完成回调
     */
    AtlasManager.loadAtlas = function (path, callback) {
        var itAtlas = AtlasManager._atlasMap.get(path);
        if (!itAtlas) {
            itAtlas = new ITAtlas_1.ITAtlas(path);
            this._atlasMap.set(path, itAtlas);
            ITResourceLoader_1.default.loadRes(path, cc.SpriteAtlas, function (err, atlas) {
                itAtlas["atlasLoaded"](err, atlas);
                callback && callback(err, atlas);
            });
        }
        // 处理引用计数
        if (AtlasManager._atlasCounter.has(path)) {
            var count = AtlasManager._atlasCounter.get(path) + 1;
            AtlasManager._atlasCounter.set(path, count);
        }
        else {
            AtlasManager._atlasCounter.set(path, 1);
        }
        return itAtlas;
    };
    /**
     * 释放图集
     * @param {string} path 图集路径
     */
    AtlasManager.releaseAtlas = function (path) {
        var count = this._atlasCounter.get(path);
        if (count > 1) {
            AtlasManager._atlasCounter.set(path, --count);
            LogUtil_1.default.log("[AtlasManager] atlas(" + path + ")\u5F15\u7528\u51CF\u4E00\uFF0C\u5F53\u524D\u4E3A:" + count);
        }
        else {
            LogUtil_1.default.log("[AtlasManager] atlas(" + path + ")\u5F15\u7528\u4E3A0\uFF0C\u91CA\u653E!");
            // TODO 依赖释放逻辑，同时需要分析编辑器里引用到的纹理关系，进行释放。
        }
    };
    /** 图集集合 */
    AtlasManager._atlasMap = new Map();
    /** 引用计数管理 */
    AtlasManager._atlasCounter = new Map();
    return AtlasManager;
}());
exports.default = AtlasManager;

cc._RF.pop();