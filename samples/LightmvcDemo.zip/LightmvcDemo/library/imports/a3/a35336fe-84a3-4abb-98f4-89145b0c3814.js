"use strict";
cc._RF.push(module, 'a3533b+hKNKu5j0iRRbDDgU', 'ArrayUtil');
// libs/core/util/ArrayUtil.ts

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * ArrayUtil:数组操作相关接口
 * @author ituuz
 */
var ArrayUtil = /** @class */ (function () {
    function ArrayUtil() {
    }
    ArrayUtil.stringify = function (src) {
        var str = "";
        for (var _i = 0, src_1 = src; _i < src_1.length; _i++) {
            var s = src_1[_i];
            str = str + " " + s.toString();
        }
        return str;
    };
    return ArrayUtil;
}());
exports.default = ArrayUtil;

cc._RF.pop();