"use strict";
cc._RF.push(module, '2b69fTuS8BMP5bB/mYkkJh2', 'LogUtil');
// libs/core/util/LogUtil.ts

Object.defineProperty(exports, "__esModule", { value: true });
var FrameworkCfg_1 = require("../../FrameworkCfg");
var ArrayUtil_1 = require("./ArrayUtil");
/**
 * LogUtil:日志相关接口
 * @author ituuz
 */
var LogUtil = /** @class */ (function () {
    function LogUtil() {
    }
    LogUtil.log = function (message) {
        var optionalParams = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            optionalParams[_i - 1] = arguments[_i];
        }
        if (FrameworkCfg_1.default.DEBUG) {
            LogUtil._logStr += "[log]" + LogUtil.GLOBAL_TAG + ":"
                + message + ArrayUtil_1.default.stringify(optionalParams) + "\n";
        }
        else {
            console.log("[log]", LogUtil.GLOBAL_TAG, ":", message, optionalParams);
        }
    };
    LogUtil.debug = function (message) {
        var optionalParams = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            optionalParams[_i - 1] = arguments[_i];
        }
        if (FrameworkCfg_1.default.DEBUG) {
            LogUtil._logStr += "[debug]" + LogUtil.GLOBAL_TAG + ":"
                + message + ArrayUtil_1.default.stringify(optionalParams) + "\n";
        }
        else {
            console.debug("[debug]", LogUtil.GLOBAL_TAG, ":", message, optionalParams);
        }
    };
    LogUtil.warn = function (message) {
        var optionalParams = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            optionalParams[_i - 1] = arguments[_i];
        }
        if (FrameworkCfg_1.default.DEBUG) {
            LogUtil._logStr += "[warn]" + LogUtil.GLOBAL_TAG + ":"
                + message + ArrayUtil_1.default.stringify(optionalParams) + "\n";
        }
        else {
            console.debug("[warn]", LogUtil.GLOBAL_TAG, ":", message, optionalParams);
        }
    };
    LogUtil.error = function (message) {
        var optionalParams = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            optionalParams[_i - 1] = arguments[_i];
        }
        if (FrameworkCfg_1.default.DEBUG) {
            LogUtil._logStr += "[error]" + LogUtil.GLOBAL_TAG + ":"
                + message + ArrayUtil_1.default.stringify(optionalParams) + "\n";
        }
        else {
            console.debug("[error]", LogUtil.GLOBAL_TAG, ":", message, optionalParams);
        }
    };
    // 写入文件保存
    LogUtil.save = function () {
        if (cc.sys.isNative) {
            var path = jsb.fileUtils.getWritablePath() + "log/" + new Date().toString() + ".txt";
            jsb.fileUtils.writeDataToFile(LogUtil._logStr, path);
            LogUtil._logStr = "";
        }
    };
    /** log标签 */
    LogUtil.GLOBAL_TAG = "LOG_TAG";
    /** log 日志信息 */
    LogUtil._logStr = "";
    return LogUtil;
}());
exports.default = LogUtil;
// 将接口导出
window.it || (window.it = {});
window.it.log = LogUtil.log;
window.it.debug = LogUtil.debug;
window.it.warn = LogUtil.warn;
window.it.error = LogUtil.error;
window.it.saveLog = LogUtil.save;

cc._RF.pop();