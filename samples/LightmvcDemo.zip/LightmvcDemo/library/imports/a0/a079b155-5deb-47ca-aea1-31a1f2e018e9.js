"use strict";
cc._RF.push(module, 'a079bFVXetHyq6hMaHy4Bjp', 'SecondMediator');
// script/view/second/SecondMediator.ts

Object.defineProperty(exports, "__esModule", { value: true });
var PlayerModel_1 = require("../../model/PlayerModel");
var SecondView_1 = require("./SecondView");
var GameMediator_1 = require("../../../libs/mvc_ex/base/GameMediator");
var SceneCfg_1 = require("../../SceneCfg");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SecondMediator = /** @class */ (function (_super) {
    __extends(SecondMediator, _super);
    function SecondMediator() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SecondMediator.prototype.init = function (data) {
        var _this = this;
        this.bindEvent(SecondView_1.default.BACK_SCENE, function () {
            _this.gotoScene(SceneCfg_1.default.DEFAULT_SCENE);
        }, this);
    };
    SecondMediator.prototype.viewDidAppear = function () {
        var playerModel = this.getModel(PlayerModel_1.default);
        var lv = playerModel.getPlayerLv();
        this.view.setData(lv);
    };
    SecondMediator.prototype.destroy = function () {
    };
    SecondMediator = __decorate([
        ccclass
    ], SecondMediator);
    return SecondMediator;
}(GameMediator_1.default));
exports.default = SecondMediator;

cc._RF.pop();