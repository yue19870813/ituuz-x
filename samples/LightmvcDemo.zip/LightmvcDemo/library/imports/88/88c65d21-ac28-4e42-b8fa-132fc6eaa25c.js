"use strict";
cc._RF.push(module, '88c650hrChOQrj6Ey/G6qJc', 'BaseScene');
// libs/core/mvc/base/BaseScene.ts

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 场景基类
 * @author ituuz
 */
var BaseView_1 = require("./BaseView");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var BaseScene = /** @class */ (function (_super) {
    __extends(BaseScene, _super);
    function BaseScene() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    BaseScene = __decorate([
        ccclass
    ], BaseScene);
    return BaseScene;
}(BaseView_1.BaseView));
exports.default = BaseScene;

cc._RF.pop();