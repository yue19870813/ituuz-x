"use strict";
cc._RF.push(module, '02b76XCcS5NyJvApN82wd/5', 'GameMediator');
// libs/mvc_ex/base/GameMediator.ts

Object.defineProperty(exports, "__esModule", { value: true });
var BaseMediator_1 = require("../../core/mvc/base/BaseMediator");
var CommandManager_1 = require("../../core/mvc/manager/CommandManager");
var LoadLayersCmd_1 = require("../command/LoadLayersCmd");
var LoadPopViewsCmd_1 = require("../command/LoadPopViewsCmd");
/**
 * BaseMediator的拓展，会处理部分游戏内部公共数据。
 * @author ituuz
 */
var GameMediator = /** @class */ (function (_super) {
    __extends(GameMediator, _super);
    function GameMediator() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    GameMediator.prototype.init = function (data) {
    };
    GameMediator.prototype.viewDidAppear = function () {
    };
    /**
     * @deprecated 不建议使用
     */
    GameMediator.prototype.runScene = function () {
        throw Error("Please use 'gotoScene()' instead of 'runScene()'.");
    };
    /**
     * @deprecated 不建议使用
     */
    GameMediator.prototype.popView = function () {
        throw Error("Please use 'addView()' instead of 'popView()'.");
    };
    /**
     * 跳转场景
     * @param {MVC_struct} sceneCfg 场景配置
     * @param {any} data 传递给下个场景的参数，自定义类型。
     */
    GameMediator.prototype.gotoScene = function (sceneCfg, data) {
        if (data === void 0) { data = null; }
        // 向新建scene传递参数
        CommandManager_1.default.getInstance().__executeCommand__(LoadLayersCmd_1.default, { mvc: sceneCfg, data: data });
    };
    /**
     * 添加新UI到界面
     * @param viewCfg {MVC_struct} sceneCfg 场景配置
     * @param {any} data 传递给新建UI的参数，自定义类型。
     */
    GameMediator.prototype.addView = function (viewCfg, data) {
        if (data === void 0) { data = null; }
        // 向新建view传递参数
        CommandManager_1.default.getInstance().__executeCommand__(LoadPopViewsCmd_1.default, { mvc: viewCfg, data: data });
    };
    GameMediator.prototype.destroy = function () {
    };
    return GameMediator;
}(BaseMediator_1.default));
exports.default = GameMediator;

cc._RF.pop();