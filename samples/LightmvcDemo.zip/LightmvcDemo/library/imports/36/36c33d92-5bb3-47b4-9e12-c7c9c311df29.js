"use strict";
cc._RF.push(module, '36c332SW7NHtJ4Sx8nDEd8p', 'SingleBase');
// libs/core/base/SingleBase.ts

Object.defineProperty(exports, "__esModule", { value: true });
var SingleBase = /** @class */ (function () {
    function SingleBase() {
    }
    return SingleBase;
}());
exports.default = SingleBase;

cc._RF.pop();