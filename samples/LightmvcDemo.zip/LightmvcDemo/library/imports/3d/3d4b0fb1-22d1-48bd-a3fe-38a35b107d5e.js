"use strict";
cc._RF.push(module, '3d4b0+xItFIvaP+OKNbEH1e', 'ImageLoader');
// libs/core/load/loader/base/ImageLoader.ts

Object.defineProperty(exports, "__esModule", { value: true });
var BaseLoader_1 = require("./BaseLoader");
var ImageLoader = /** @class */ (function (_super) {
    __extends(ImageLoader, _super);
    function ImageLoader() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    ImageLoader.prototype.loadNetRes = function (path, type, callback) {
        // TODO 加载网络图片资源
        throw new Error("ImageLoader loadNetRes method not implemented.");
    };
    ImageLoader.prototype.loadRemoteRes = function (path, type, callback) {
        // TODO 加载远程待下载图片资源
        throw new Error("ImageLoader loadRemoteRes method not implemented.");
    };
    ImageLoader.prototype.loadLocalRes = function (path, type, callback) {
        cc.loader.loadRes(path, type, callback);
    };
    return ImageLoader;
}(BaseLoader_1.default));
exports.default = ImageLoader;

cc._RF.pop();