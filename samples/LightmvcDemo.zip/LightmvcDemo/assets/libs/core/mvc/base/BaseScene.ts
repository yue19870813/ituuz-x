/**
 * 场景基类
 * @author ituuz
 */
import { BaseView } from "./BaseView";

const {ccclass, property} = cc._decorator;

@ccclass
export default class BaseScene extends BaseView {
    
}
