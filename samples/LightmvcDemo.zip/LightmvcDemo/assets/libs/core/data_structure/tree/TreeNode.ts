
export default class TreeNode {

    public parent: TreeNode;

    public children: TreeNode[];

    public data: any;

    public constructor (data: any) {

    } 
}