import GameMediator from "../../../libs/mvc_ex/base/GameMediator";

export default class TopMediator extends GameMediator {
    
}