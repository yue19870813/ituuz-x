import FirstView from "./FirstView";
import PopAMediator from "../pop_a/PopAMediator";
import PopAView from "../pop_a/PopAView";
import PopBMediator from "../pop_b/PopBMediator";
import PopBView from "../pop_b/PopBView";
import GameMediator from "../../../libs/mvc_ex/base/GameMediator";
import { ViewCfg } from "../../SceneCfg";


export default class FirstMediator extends GameMediator {

    public view: FirstView;
    
    public init(data?: any): void {
        console.log("FirstMediator::init===>>>", data);
        this.view.setData(data);

        this.bindEvent(FirstView.OPEN_A, (str: string)=>{
            this.addView(ViewCfg.POP_A_VIEW);
        }, this);

        this.bindEvent(FirstView.OPEN_B, (str: string)=>{
            this.addView(ViewCfg.POP_B_VIEW);
        }, this);
    }    
    
    public viewDidAppear(): void {

    }

    public destroy(): void {

    }
 
}
