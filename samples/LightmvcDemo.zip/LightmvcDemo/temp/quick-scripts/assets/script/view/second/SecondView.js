(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/view/second/SecondView.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'fa509BfxlNProbaHZw3QgNR', 'SecondView', __filename);
// script/view/second/SecondView.ts

Object.defineProperty(exports, "__esModule", { value: true });
var GameView_1 = require("../../../libs/mvc_ex/base/GameView");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SecondView = /** @class */ (function (_super) {
    __extends(SecondView, _super);
    function SecondView() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SecondView_1 = SecondView;
    SecondView.prototype.init = function () {
        var _this = this;
        var backBtn = this.ui.getNode("back_btn");
        backBtn.on(cc.Node.EventType.TOUCH_END, function () {
            // 返回上一场景
            _this.sendEvent(SecondView_1.BACK_SCENE);
        }, this);
    };
    SecondView.prototype.setData = function (lv) {
        var lvLabel = this.ui.getComponent("lv_label", cc.Label);
        lvLabel.string = "当前等级为：" + lv;
    };
    SecondView.path = function () {
        return "prefabs/second_view";
    };
    var SecondView_1;
    SecondView.BACK_SCENE = "BACK_SCENE";
    SecondView = SecondView_1 = __decorate([
        ccclass
    ], SecondView);
    return SecondView;
}(GameView_1.default));
exports.default = SecondView;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=SecondView.js.map
        