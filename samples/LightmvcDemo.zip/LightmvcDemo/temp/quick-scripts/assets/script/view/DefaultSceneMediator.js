(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/view/DefaultSceneMediator.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'ad327DTnMRJp44xOk9Qj8CV', 'DefaultSceneMediator', __filename);
// script/view/DefaultSceneMediator.ts

Object.defineProperty(exports, "__esModule", { value: true });
var GameMediator_1 = require("../../libs/mvc_ex/base/GameMediator");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var DefaultSceneMediator = /** @class */ (function (_super) {
    __extends(DefaultSceneMediator, _super);
    function DefaultSceneMediator() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    DefaultSceneMediator.prototype.init = function (data) {
        console.log("打开场景时传递的参数:", data);
        this._data = data;
    };
    DefaultSceneMediator.prototype.viewDidAppear = function () {
        console.log("viewDidAppear ===>>>", this._data);
        // 打开第一个UI
        // this.addLayer(FirstMediator, FirstView, 1, this._data);
    };
    DefaultSceneMediator.prototype.destroy = function () {
    };
    DefaultSceneMediator = __decorate([
        ccclass
    ], DefaultSceneMediator);
    return DefaultSceneMediator;
}(GameMediator_1.default));
exports.default = DefaultSceneMediator;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=DefaultSceneMediator.js.map
        