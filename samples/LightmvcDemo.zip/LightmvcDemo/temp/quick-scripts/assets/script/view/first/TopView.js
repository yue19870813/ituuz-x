(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/view/first/TopView.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '17bb07Bh8NB44qaCP4igsPm', 'TopView', __filename);
// script/view/first/TopView.ts

Object.defineProperty(exports, "__esModule", { value: true });
var GameView_1 = require("../../../libs/mvc_ex/base/GameView");
var TopView = /** @class */ (function (_super) {
    __extends(TopView, _super);
    function TopView() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    TopView.prototype.init = function () {
        console.log("init");
    };
    TopView.prototype.start = function () {
    };
    TopView.path = function () {
        return "prefabs/top_view";
    };
    return TopView;
}(GameView_1.default));
exports.default = TopView;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=TopView.js.map
        