"use strict";
cc._RF.push(module, 'a7b9fNVhddN65LCnVTALNNE', 'HttpClient');
// libs/extension/net/HttpClient.ts

Object.defineProperty(exports, "__esModule", { value: true });
var NetClientBase_1 = require("./NetClientBase");
var NetHelper_1 = require("./NetHelper");
/**
 * http消息发送和解析
 * @author ituuz
 */
var HttpClient = /** @class */ (function (_super) {
    __extends(HttpClient, _super);
    function HttpClient() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /**
     * 发送消息协议
     * @param {MessageBase} msg 消息对象
     */
    HttpClient.prototype.sendReq = function (msg) {
        var _this = this;
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && (xhr.status >= 200 && xhr.status < 400)) {
                var response = xhr.response;
                _this.encode(response);
            }
        };
        xhr.open("POST", this.addr, true);
        var buffer = this.decode(msg);
        xhr.send(buffer);
    };
    /**
     * 对消息体进行压包
     * @param {MessageBase} msg 消息对象
     * @return {ArrayBuffer} 压包后的而进行数据
     * int32 协议id
     * int32 协议体长度
     * data 协议体
     */
    HttpClient.prototype.decode = function (msg) {
        var buffer = msg.toBuffer();
        var dataView = new DataView(buffer);
        var dataLen = buffer.byteLength;
        var sendBuf = new ArrayBuffer(HttpClient.DATA_TOTAL_LEN + HttpClient.PROTOCOLTYPE_LEN + dataLen);
        var sendView = new DataView(sendBuf);
        sendView.setInt32(0, msg.PID);
        sendView.setInt32(HttpClient.PROTOCOLTYPE_LEN, dataLen);
        for (var i = 0; i < dataLen; i++) {
            sendView.setInt8(HttpClient.PROTOCOLTYPE_LEN + HttpClient.DATA_TOTAL_LEN + i, dataView.getInt8(i));
        }
        return sendBuf;
    };
    /**
     * 对二进制数据进行解包
     * @param {ArrayBuffer} recvBuf 接收到的二进制数据
     */
    HttpClient.prototype.encode = function (recvBuf) {
        var recvView = new DataView(recvBuf);
        var PID = recvView.getInt32(0);
        var data = recvBuf.slice(HttpClient.DATA_TOTAL_LEN + HttpClient.PROTOCOLTYPE_LEN, recvBuf.byteLength);
        var cls = NetHelper_1.NetHelper.getMessageCls(PID);
        var msg = cls.create(function () {
            msg.parseBuffer(data);
        });
    };
    // 数据总长度
    HttpClient.DATA_TOTAL_LEN = 4;
    // 协议号长度
    HttpClient.PROTOCOLTYPE_LEN = 4;
    return HttpClient;
}(NetClientBase_1.default));
exports.default = HttpClient;

cc._RF.pop();