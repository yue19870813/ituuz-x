"use strict";
cc._RF.push(module, 'd5dd3yG8mdG/IpB7WeIu0ES', 'TreeNode');
// libs/core/data_structure/tree/TreeNode.ts

Object.defineProperty(exports, "__esModule", { value: true });
var TreeNode = /** @class */ (function () {
    function TreeNode(data) {
    }
    return TreeNode;
}());
exports.default = TreeNode;

cc._RF.pop();