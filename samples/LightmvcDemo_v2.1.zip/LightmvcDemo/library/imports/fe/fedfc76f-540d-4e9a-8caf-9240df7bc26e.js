"use strict";
cc._RF.push(module, 'fedfcdvVA1OmoyvkkDfe8Ju', 'BaseCommand');
// libs/core/mvc/base/BaseCommand.ts

/**
 * 命令基类
 * @author ituuz
 */
Object.defineProperty(exports, "__esModule", { value: true });
var BaseCommand = /** @class */ (function () {
    function BaseCommand() {
    }
    return BaseCommand;
}());
exports.default = BaseCommand;

cc._RF.pop();