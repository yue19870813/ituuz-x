"use strict";
cc._RF.push(module, '24d91Wg3HhBc4jbR2G2tnhB', 'Framework');
// libs/Framework.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Facade_1 = require("./core/mvc/Facade");
var CommandManager_1 = require("./core/mvc/manager/CommandManager");
var LoadLayersCmd_1 = require("./mvc_ex/command/LoadLayersCmd");
/**
 * 框架煮类，用户初始化框架以及提供一些框架级别的接口。
 * @author ituuz
 */
var Framework = /** @class */ (function () {
    function Framework() {
    }
    /**
     * 初始化框架接口
     * @param {MVC_struct} scene 初始化游戏的第一个场景
     * @param {boolean} debug 框架是否是调试模式
     * @param {cc.Size} designResolution 默认的设计分辨率
     * @param {boolean} fitWidth 是否宽适配
     * @param {boolean} fitHeight 是否高适配
     */
    Framework.start = function (scene, models, debug, designResolution, fitWidth, fitHeight) {
        if (debug === void 0) { debug = true; }
        if (designResolution === void 0) { designResolution = cc.size(960, 640); }
        if (fitWidth === void 0) { fitWidth = false; }
        if (fitHeight === void 0) { fitHeight = false; }
        Facade_1.Facade.getInstance().init(debug, designResolution, fitWidth, fitHeight);
        Framework.registerModels(models);
        // 运行第一个场景
        CommandManager_1.default.getInstance().__executeCommand__(LoadLayersCmd_1.default, { mvc: scene, data: null });
    };
    /**
     * 注册数据model
     * @param {{new (): BaseModel}} model
     */
    Framework.registerModels = function (models) {
        for (var _i = 0, models_1 = models; _i < models_1.length; _i++) {
            var model = models_1[_i];
            Facade_1.Facade.getInstance().registerModel(model);
        }
    };
    /**
     * 获取model对象
     * @param {{new (): BaseModel}} model
     */
    Framework.getModel = function (model) {
        return Facade_1.Facade.getInstance().getModel(model);
    };
    return Framework;
}());
exports.default = Framework;
/**
 * 一个场景或者UI层的配置结构
 */
var MVC_struct = /** @class */ (function () {
    function MVC_struct() {
    }
    return MVC_struct;
}());
exports.MVC_struct = MVC_struct;
// 将接口导出
window.it || (window.it = {});
window.it.Framework = Framework;

cc._RF.pop();