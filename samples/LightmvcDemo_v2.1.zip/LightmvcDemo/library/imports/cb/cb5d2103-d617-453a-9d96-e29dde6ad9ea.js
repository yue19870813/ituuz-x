"use strict";
cc._RF.push(module, 'cb5d2ED1hdFOp2W4p3eatnq', 'WebsocketClient');
// libs/extension/net/WebsocketClient.ts

Object.defineProperty(exports, "__esModule", { value: true });
var NetClientBase_1 = require("./NetClientBase");
/**
 * WebsocketClient
 * @author ituuz
 */
var WebsocketClient = /** @class */ (function (_super) {
    __extends(WebsocketClient, _super);
    function WebsocketClient() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    WebsocketClient.prototype.sendReq = function (msg) {
        throw new Error("Method not implemented.");
    };
    return WebsocketClient;
}(NetClientBase_1.default));
exports.default = WebsocketClient;

cc._RF.pop();