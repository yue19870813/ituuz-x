"use strict";
cc._RF.push(module, 'c900eyah15JlZg9TZTeUocw', 'ITResourceLoader');
// libs/core/load/loader/ITResourceLoader.ts

Object.defineProperty(exports, "__esModule", { value: true });
var LogUtil_1 = require("../../util/LogUtil");
var AtlasLoader_1 = require("./base/AtlasLoader");
var ImageLoader_1 = require("./base/ImageLoader");
var PrefabLoader_1 = require("./base/PrefabLoader");
var TextLoader_1 = require("./base/TextLoader");
var JsonLoader_1 = require("./base/JsonLoader");
var ITResourceLoader = /** @class */ (function () {
    function ITResourceLoader() {
    }
    ITResourceLoader.init = function () {
        // 初始化加载器map
        ITResourceLoader._defaultMap = new Map();
        // image loader
        ITResourceLoader._defaultMap.set(cc.SpriteFrame, ITResourceLoader._imageLoader);
        // atlas loader
        ITResourceLoader._defaultMap.set(cc.SpriteAtlas, ITResourceLoader._atlasLoader);
        // prefab loader
        ITResourceLoader._defaultMap.set(cc.Prefab, ITResourceLoader._prefabLoader);
        // text loader
        ITResourceLoader._defaultMap.set(cc.TextAsset, ITResourceLoader._textLoader);
        // json loader
        ITResourceLoader._defaultMap.set(cc.JsonAsset, ITResourceLoader._jsonLoader);
        // TODO dragonbone loader
        // TODO spine loader
        // TODO tilemap loader
    };
    /**
     * 资源统一加载接口
     * @param {string} path 资源路径
     * @param {cc.Asset} type 资源类型
     * @param {(err, res) => void} callback 加载完成回调
     */
    ITResourceLoader.loadRes = function (path, type, callback) {
        // 根据资源类型获取对应的加载器
        var itemLoader = ITResourceLoader._defaultMap.get(type);
        if (itemLoader) {
            itemLoader.loadRes(path, type, callback);
        }
        else {
            LogUtil_1.default.error("[ITResourceLoader]The type [" + type + "] of res [" + path + "] is not support yet!");
            cc.loader.loadRes(path, type, callback);
        }
    };
    // loader加载器实例
    ITResourceLoader._imageLoader = new ImageLoader_1.default();
    ITResourceLoader._atlasLoader = new AtlasLoader_1.default();
    ITResourceLoader._prefabLoader = new PrefabLoader_1.default();
    ITResourceLoader._textLoader = new TextLoader_1.default();
    ITResourceLoader._jsonLoader = new JsonLoader_1.default();
    return ITResourceLoader;
}());
exports.default = ITResourceLoader;
// 默认初始化加载器管理类
ITResourceLoader.init();
// 将接口导出
window.it || (window.it = {});
window.it.loader = ITResourceLoader;

cc._RF.pop();