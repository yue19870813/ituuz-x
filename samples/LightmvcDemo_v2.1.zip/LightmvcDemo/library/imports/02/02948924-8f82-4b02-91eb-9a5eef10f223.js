"use strict";
cc._RF.push(module, '02948kkj4JLApHrml7vEPIj', 'ModelManager');
// libs/core/mvc/manager/ModelManager.ts

Object.defineProperty(exports, "__esModule", { value: true });
var ModelManager = /** @class */ (function () {
    /**
     * @constructor
     * @private
     */
    function ModelManager() {
        this._modelList = {};
    }
    /**
     * 单例获取类
     */
    ModelManager.getInstance = function () {
        return this._instance;
    };
    /**
     * 获取model对象
     * @param {{new (): BaseModel}} model
     */
    ModelManager.prototype.getModel = function (model) {
        var key = cc.js.getClassName(model);
        return this._modelList[key];
    };
    /**
     * 注册数据model
     * @param {{new (): BaseModel}} model
     */
    ModelManager.prototype.registerModel = function (model) {
        var key = cc.js.getClassName(model);
        if (this._modelList.hasOwnProperty(key)) {
            console.log(key, "已经存在，不可重复注册！");
        }
        else {
            var m = new model();
            m.init();
            this._modelList[key] = m;
        }
    };
    /**
     * 移除注册
     * @param {{new (): BaseModel}} model
     */
    ModelManager.prototype.unregisterModel = function (model) {
        var key = cc.js.getClassName(model);
        if (this._modelList.hasOwnProperty(key)) {
            var m = this._modelList[key];
            m.clear();
            delete this._modelList[key];
        }
        else {
            console.warn(key, "不存在！");
        }
    };
    /**
     * 释放并移除所有model
     */
    ModelManager.prototype.removeAllModel = function () {
        //  释放并移除所有model
        for (var key in this._modelList) {
            var model = this._modelList[key];
            model.clear();
            delete this._modelList[key];
        }
        this._modelList = {};
    };
    /** 实例 */
    ModelManager._instance = new ModelManager();
    return ModelManager;
}());
exports.default = ModelManager;

cc._RF.pop();