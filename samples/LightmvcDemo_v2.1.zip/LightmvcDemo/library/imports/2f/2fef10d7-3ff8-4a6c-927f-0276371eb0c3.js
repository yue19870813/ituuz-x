"use strict";
cc._RF.push(module, '2fef1DXP/hKbJJ/AnY3HrDD', 'MultiwayTree');
// libs/core/data_structure/tree/MultiwayTree.ts

Object.defineProperty(exports, "__esModule", { value: true });
var TreeNode_1 = require("./TreeNode");
var MultiwayTree = /** @class */ (function () {
    function MultiwayTree() {
        this._root = null;
    }
    //深度优先遍历
    MultiwayTree.prototype.traverseDF = function (callback) {
        var stack = [];
        var found = false;
        stack.unshift(this._root);
        var currentNode = stack.shift();
        while (!found && currentNode) {
            found = callback(currentNode) === true ? true : false;
            if (!found) {
                stack.unshift.apply(stack, currentNode.children);
                currentNode = stack.shift();
            }
        }
    };
    //广度优先遍历
    MultiwayTree.prototype.traverseBF = function (callback) {
        var queue = [];
        var found = false;
        queue.push(this._root);
        var currentNode = queue.shift();
        while (!found && currentNode) {
            found = callback(currentNode) === true ? true : false;
            if (!found) {
                queue.push.apply(queue, currentNode.children);
                currentNode = queue.shift();
            }
        }
    };
    MultiwayTree.prototype.add = function (data, toData, traversal) {
        var node = new TreeNode_1.default(data);
        // 第一次添加到根节点
        // 返回值为this，便于链式添加节点
        if (this._root === null) {
            this._root = node;
            return this;
        }
        var parent = null;
        var callback = function (node) {
            if (node.data === toData) {
                parent = node;
                return true;
            }
        };
        // 根据遍历方法查找父节点（遍历方法后面会讲到），然后把节点添加到父节点
        // 的children数组里
        // 查找方法contains后面会讲到
        traversal.call(this, callback);
        // this.contains(callback, traversal);  
        this.contains(callback, traversal);
        if (parent) {
            parent.children.push(node);
            node.parent = parent;
            return this;
        }
        else {
            throw new Error('Cannot add node to a non-existent parent.');
        }
    };
    MultiwayTree.prototype.contains = function (callback, traversal) {
        traversal.call(this, callback);
    };
    MultiwayTree.prototype.remove = function (data, fromData, traversal) {
        var parent = null;
        var childToRemove = null;
        var callback = function (node) {
            if (node.data === fromData) {
                parent = node;
                return true;
            }
        };
        this.contains(callback, traversal);
        if (parent) {
            var index = this._findIndex(parent.children, data);
            if (index < 0) {
                throw new Error('Node to remove does not exist.');
            }
            else {
                childToRemove = parent.children.splice(index, 1);
            }
        }
        else {
            throw new Error('Parent does not exist.');
        }
        return childToRemove;
    };
    MultiwayTree.prototype._findIndex = function (arr, data) {
        var index = -1;
        for (var i = 0, len = arr.length; i < len; i++) {
            if (arr[i].data === data) {
                index = i;
                break;
            }
        }
        return index;
    };
    return MultiwayTree;
}());
exports.default = MultiwayTree;

cc._RF.pop();