"use strict";
cc._RF.push(module, '4c9daANf5tB9p1qEpB/+nR0', 'GameMediator');
// libs/mvc_ex/base/GameMediator.ts

/**
 * BaseMediator的拓展，会处理部分游戏内部公共数据。
 * @author ituuz
 */
Object.defineProperty(exports, "__esModule", { value: true });
var BaseMediator_1 = require("../../core/mvc/base/BaseMediator");
var LoadLayersCmd_1 = require("../command/LoadLayersCmd");
var LoadPopViewsCmd_1 = require("../command/LoadPopViewsCmd");
var GameMediator = /** @class */ (function (_super) {
    __extends(GameMediator, _super);
    function GameMediator() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    GameMediator.prototype.init = function (data) {
    };
    GameMediator.prototype.customInit = function () {
    };
    GameMediator.prototype.viewDidAppear = function () {
    };
    /**
     * @deprecated 不建议使用
     */
    GameMediator.prototype.runScene = function () {
        throw Error("Please use 'gotoScene()' instead of 'runScene()'.");
    };
    /**
     * @deprecated 不建议使用
     */
    GameMediator.prototype.popView = function () {
        throw Error("Please use 'addView()' instead of 'popView()'.");
    };
    /**
     * 跳转场景
     * @param {MVC_struct} sceneCfg 场景配置
     * @param {any} data 传递给下个场景的参数，自定义类型。
     */
    GameMediator.prototype.gotoScene = function (sceneCfg, data) {
        if (data === void 0) { data = null; }
        // 向新建scene传递参数
        this.sendCmd(LoadLayersCmd_1.default, { mvc: sceneCfg, data: data });
    };
    /**
     * 添加新UI到界面
     * @param viewCfg {MVC_struct} sceneCfg 场景配置
     * @param {any} data 传递给新建UI的参数，自定义类型。
     * @param {cc.Node} parent 父节点对象，可选
     * @param {boolean} useCache 是否使用已经存在的缓存View，可选，默认不使用false。
     */
    GameMediator.prototype.addView = function (viewCfg, data, parent, useCache) {
        // 向新建view传递参数
        this.sendCmd(LoadPopViewsCmd_1.default, { mvc: viewCfg, data: data, parent: parent, useCache: useCache });
    };
    GameMediator.prototype.destroy = function () {
    };
    return GameMediator;
}(BaseMediator_1.default));
exports.default = GameMediator;

cc._RF.pop();