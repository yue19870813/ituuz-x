"use strict";
cc._RF.push(module, 'fa743UR3KZDpZ/HtJi90fb8', 'TopMediator');
// script/view/first/TopMediator.ts

Object.defineProperty(exports, "__esModule", { value: true });
var GameMediator_1 = require("../../../libs/mvc_ex/base/GameMediator");
var TopMediator = /** @class */ (function (_super) {
    __extends(TopMediator, _super);
    function TopMediator() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return TopMediator;
}(GameMediator_1.default));
exports.default = TopMediator;

cc._RF.pop();