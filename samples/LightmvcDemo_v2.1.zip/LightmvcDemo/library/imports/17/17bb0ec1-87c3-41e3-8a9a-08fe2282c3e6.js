"use strict";
cc._RF.push(module, '17bb07Bh8NB44qaCP4igsPm', 'TopView');
// script/view/first/TopView.ts

Object.defineProperty(exports, "__esModule", { value: true });
var GameView_1 = require("../../../libs/mvc_ex/base/GameView");
var TopView = /** @class */ (function (_super) {
    __extends(TopView, _super);
    function TopView() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    TopView.prototype.init = function () {
        console.log("init");
    };
    TopView.prototype.start = function () {
    };
    TopView.path = function () {
        return "prefabs/top_view";
    };
    return TopView;
}(GameView_1.default));
exports.default = TopView;

cc._RF.pop();