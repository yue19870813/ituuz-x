"use strict";
cc._RF.push(module, 'ee3c8eOnP9HOYbkk4FgL5WO', 'PlayerModel');
// script/model/PlayerModel.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Notification_1 = require("../Notification");
var BaseModel_1 = require("../../libs/core/mvc/base/BaseModel");
var PlayerModel = /** @class */ (function (_super) {
    __extends(PlayerModel, _super);
    function PlayerModel() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    PlayerModel.prototype.init = function () {
        this._player = new Player("Spider man");
    };
    PlayerModel.prototype.setPlayerExp = function (exp) {
        this._player.exp = this._player.exp + exp;
        this.sendNoti(Notification_1.default.UPDATE_EXP_FINISH);
    };
    PlayerModel.prototype.getPlayer = function () {
        return this._player;
    };
    PlayerModel.prototype.getPlayerLv = function () {
        return Math.ceil(this._player.exp / 10);
    };
    PlayerModel.prototype.clear = function () {
    };
    return PlayerModel;
}(BaseModel_1.default));
exports.default = PlayerModel;
var Player = /** @class */ (function () {
    function Player(name, exp) {
        this.name = name;
        if (exp) {
            this.exp = exp;
        }
        else {
            this.exp = 0;
        }
    }
    return Player;
}());
exports.Player = Player;

cc._RF.pop();