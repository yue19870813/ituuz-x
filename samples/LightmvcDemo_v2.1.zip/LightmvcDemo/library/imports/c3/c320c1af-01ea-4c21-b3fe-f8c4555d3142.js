"use strict";
cc._RF.push(module, 'c320cGvAepMIbP++MRVXTFC', 'JsonLoader');
// libs/core/load/loader/base/JsonLoader.ts

Object.defineProperty(exports, "__esModule", { value: true });
var BaseLoader_1 = require("./BaseLoader");
var JsonLoader = /** @class */ (function (_super) {
    __extends(JsonLoader, _super);
    function JsonLoader() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    JsonLoader.prototype.loadNetRes = function (path, type, callback) {
        // TODO 加载网络Json资源
        throw new Error("JsonLoader loadNetRes method not implemented.");
    };
    JsonLoader.prototype.loadRemoteRes = function (path, type, callback) {
        // TODO 加载远程待下载Json资源
        throw new Error("JsonLoader loadRemoteRes method not implemented.");
    };
    JsonLoader.prototype.loadLocalRes = function (path, type, callback) {
        cc.loader.loadRes(path, type, callback);
    };
    return JsonLoader;
}(BaseLoader_1.default));
exports.default = JsonLoader;

cc._RF.pop();