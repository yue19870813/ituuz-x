"use strict";
cc._RF.push(module, 'b7754r2JyRBIrh7Lh7Gz6yN', 'ViewManager');
// libs/core/mvc/manager/ViewManager.ts

Object.defineProperty(exports, "__esModule", { value: true });
var FrameworkCfg_1 = require("../../../FrameworkCfg");
var Constants_1 = require("../Constants");
var ITResourceLoader_1 = require("../../load/loader/ITResourceLoader");
/**
 * mvc框架控制类
 * @author ituuz
 * @description 负责控制和维护框架各个节点和结构间的跳转和关联。
 */
var ViewManager = /** @class */ (function () {
    /**
     * @constructor
     * @private
     */
    function ViewManager() {
        /** 上一场景类 */
        this._preSceneMediatorCls = null;
        this._preSceneViewCls = null;
        /** 当前场景类 */
        this._curSceneMediatorCls = null;
        this._curSceneViewCls = null;
        /** 当前场景Layer的最高层级 */
        this._maxLayerZorder = 0;
        this._popViewList = [];
        this._layerViewList = [];
    }
    /**
     * 单例获取类
     */
    ViewManager.getInstance = function () {
        return this._instance;
    };
    /**
     * 运行场景
     * @param {{new(): BaseMediator}} mediator 场景mediator类型，类类型。
     * @param {{new(): BaseScene}} view 场景mediator类型，类类型。
     * @param {Object} data 自定义的任意类型透传数据。（可选）
     * @param {()=>void} cb 加载完成回调.
     * @private
     */
    ViewManager.prototype.__runScene__ = function (mediator, view, data, cb) {
        var _this = this;
        // 初始化场景全局层级缓存
        this._maxLayerZorder = 0;
        // 创建并绑定场景
        var sceneMediator = new mediator();
        // 如果前一场景不为空则进行清理
        if (this._curScene) {
            this._curScene.destroy();
        }
        // 保存当前场景
        this._curScene = sceneMediator;
        // tslint:disable-next-line: no-string-literal
        sceneMediator["__init__"]();
        sceneMediator.init(data);
        if (this._curSceneMediatorCls != null && this._curSceneViewCls != null) {
            this._preSceneMediatorCls = this._curSceneMediatorCls;
            this._preSceneViewCls = this._curSceneViewCls;
        }
        this._curSceneMediatorCls = mediator;
        this._curSceneViewCls = view;
        // 处理场景显示逻辑
        var scenePath = view.path();
        if (scenePath === "") {
            var ccs_1 = new cc.Scene();
            ccs_1.name = "Scene";
            var canvasNode = new cc.Node();
            canvasNode.name = "Canvas";
            var canvas = canvasNode.addComponent(cc.Canvas);
            canvas.designResolution = FrameworkCfg_1.default.DESIGN_RESOLUTION;
            canvas.fitHeight = FrameworkCfg_1.default.FIT_HEIGHT;
            canvas.fitWidth = FrameworkCfg_1.default.FIT_WIDTH;
            sceneMediator.view = canvasNode.addComponent(view);
            sceneMediator.view.__init__();
            ccs_1.addChild(canvasNode);
            // 这里延迟1ms是为了让场景在下一帧加载
            setTimeout(function () {
                _this.__closeAllView__();
                cc.director.runSceneImmediate(ccs_1);
                sceneMediator.viewDidAppear();
                if (cb) {
                    cb(sceneMediator);
                }
            }, 1);
        }
        else {
            this.__closeAllView__();
            cc.director.loadScene(scenePath, function () {
                var canvas = cc.director.getScene().getChildByName("Canvas");
                if (canvas) {
                    sceneMediator.view = canvas.addComponent(view);
                    sceneMediator.view.__init__();
                    sceneMediator.viewDidAppear();
                    if (cb) {
                        cb(sceneMediator);
                    }
                }
                else {
                    it.log("场景中必须包含默认的Canvas节点！");
                }
            });
        }
    };
    /**
     * 返回上一场景
     * @returns {boolean}是否存在上一个场景
     */
    ViewManager.prototype.__backScene__ = function () {
        if (this._preSceneMediatorCls && this._preSceneViewCls) {
            this.__runScene__(this._preSceneMediatorCls, this._preSceneViewCls);
            return true;
        }
        return false;
    };
    /**
     * 打开view界面
     * @param {{new(): BaseMediator}} mediator 界面mediator类型，类类型。
     * @param {{new(): BaseView}} view view 场景mediator类型，类类型。
     * @param {Object} data 自定义的任意类型透传数据。（可选）
     * @param {OPEN_VIEW_OPTION} option 打开ui的操作选项，枚举类型。
     * @param {number} zOrder 层级。
     * @param {(view: BaseView)=>void} cb 加载完成回调.
     * @param {boolean} useCache 是否复用已存在的view 可选
     */
    ViewManager.prototype.__showView__ = function (mediator, view, data, option, zOrder, cb, parent, useCache) {
        var _this = this;
        // 如果使用缓存，则查找是否有缓存，如果有直接使用缓存对象，然后调整层级到最高
        if (useCache) {
            var isUseCache = this.useCache(mediator);
            if (isUseCache) {
                return;
            }
        }
        // 处理打开UI的其他操作
        this.openViewOptionHandler(option);
        // 创建并绑定view
        var viewMediator = new mediator();
        // tslint:disable-next-line: no-string-literal
        viewMediator["_name"] = mediator;
        // tslint:disable-next-line: no-string-literal
        viewMediator["__init__"]();
        // 处理场景显示逻辑
        var viewPath = view.path();
        if (viewPath === "") {
            var viewNode = new cc.Node();
            viewMediator.init(data);
            this.initViewMediator(viewMediator, viewNode, view, option, zOrder, parent);
            viewMediator.viewDidAppear();
            if (cb) {
                cb(viewMediator.view);
            }
        }
        else {
            ITResourceLoader_1.default.loadRes(viewPath, cc.Prefab, function (err, prefab) {
                if (err) {
                    it.error(err);
                    return;
                }
                var viewNode = cc.instantiate(prefab);
                viewMediator.init(data);
                _this.initViewMediator(viewMediator, viewNode, view, option, zOrder, parent);
                viewMediator.viewDidAppear();
                if (cb) {
                    cb(viewMediator.view);
                }
            });
        }
    };
    /** 当需要复用缓存view时 */
    ViewManager.prototype.useCache = function (mediator) {
        var isExist = false;
        for (var _i = 0, _a = this._popViewList; _i < _a.length; _i++) {
            var med = _a[_i];
            if (mediator === med["_name"]) {
                med.view.node.zIndex = this._maxLayerZorder + 20;
                isExist = true;
            }
            else {
                med.view.node.zIndex = this._maxLayerZorder + 10;
            }
        }
        return isExist;
    };
    /**
     * 初始化ViewMediator
     * @param {BaseMediator} mediator ViewMediator
     * @param {cc.Node} viewNode view显示节点
     * @param {{new(): BaseView}} view view显示组件类
     * @param {OPEN_VIEW_OPTION} option 打开选项
     * @param {number} zOrder 层级排序
     */
    ViewManager.prototype.initViewMediator = function (mediator, viewNode, view, option, zOrder, parent) {
        mediator.view = viewNode.addComponent(view);
        if (parent) {
            parent.addChild(viewNode);
        }
        else {
            cc.director.getScene().getChildByName("Canvas").addChild(viewNode);
        }
        mediator.view.__init__();
        // 根据不同打开类型，存储到不同队列中。
        if (option === Constants_1.OPEN_VIEW_OPTION.OVERLAY || option === Constants_1.OPEN_VIEW_OPTION.SINGLE) {
            // 这里处理层级设置：保障popview层级大于layer层级，这里固定大于10.
            viewNode.zIndex = this._maxLayerZorder + 10;
            this._popViewList.push(mediator);
        }
        else if (option === Constants_1.OPEN_VIEW_OPTION.LAYER) {
            viewNode.zIndex = zOrder;
            this._layerViewList.push(mediator);
            if (zOrder > this._maxLayerZorder) {
                this._maxLayerZorder = zOrder;
            }
        }
    };
    /**
     * 关闭指定View
     * @param view
     * @private
     */
    ViewManager.prototype.__closeView__ = function (view) {
        for (var i = 0; i < this._popViewList.length; i++) {
            if (this._popViewList[i].view === view) {
                this._popViewList.splice(i, 1);
                return;
            }
        }
        for (var i = 0; i < this._layerViewList.length; i++) {
            if (this._layerViewList[i].view === view) {
                this._layerViewList.splice(i, 1);
                return;
            }
        }
    };
    /**
     * 关闭所有弹出窗口
     * @private
     */
    ViewManager.prototype.__closeAllPopView__ = function () {
        for (var _i = 0, _a = this._popViewList; _i < _a.length; _i++) {
            var popView = _a[_i];
            popView["__destroy__"]();
        }
        this._popViewList = [];
    };
    /**
     * 关闭所有添加层级
     * @private
     */
    ViewManager.prototype.__closeAllAddLayer__ = function () {
        for (var _i = 0, _a = this._layerViewList; _i < _a.length; _i++) {
            var layerView = _a[_i];
            // tslint:disable-next-line: no-string-literal
            layerView["__destroy__"]();
        }
        this._layerViewList = [];
    };
    /**
     * 关闭所有view
     * @private
     */
    ViewManager.prototype.__closeAllView__ = function () {
        this.__closeAllPopView__();
        this.__closeAllAddLayer__();
    };
    /**
     * 根据参数处理ui的打开方式
     * @param option
     * @private
     */
    ViewManager.prototype.openViewOptionHandler = function (option) {
        // 设置默认值
        if (!option) {
            option = Constants_1.OPEN_VIEW_OPTION.OVERLAY;
        }
        // 根据不同操作做不同处理
        if (option === Constants_1.OPEN_VIEW_OPTION.SINGLE) {
            // TODO:暂时不提供这种关闭其他view的打开方式，可以通过BaseView.closeAllPopView()来实现。
        }
    };
    Object.defineProperty(ViewManager.prototype, "popViewList", {
        /**************************** getter and setter ******************************/
        get: function () {
            return this._popViewList;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ViewManager.prototype, "layerViewList", {
        get: function () {
            return this._layerViewList;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ViewManager.prototype, "curScene", {
        get: function () {
            return this._curScene;
        },
        enumerable: true,
        configurable: true
    });
    // 实例
    ViewManager._instance = new ViewManager();
    return ViewManager;
}());
exports.ViewManager = ViewManager;

cc._RF.pop();