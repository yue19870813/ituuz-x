"use strict";
cc._RF.push(module, '1a79evljsFBx5iSt+upDAOo', 'NetHelper');
// libs/extension/net/NetHelper.ts

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 网络消息处理Helper
 * @author ituuz
 * @description 主要负责网络消息的注册监听，发送，和链接类型管理
 */
var LogUtil_1 = require("../../core/util/LogUtil");
var HttpClient_1 = require("./HttpClient");
var LocalClient_1 = require("./LocalClient");
var WebsocketClient_1 = require("./WebsocketClient");
var PBUtils_1 = require("./PBUtils");
/**
 * 网络类型
 */
var NetType;
(function (NetType) {
    NetType[NetType["LOCAL"] = 1] = "LOCAL";
    NetType[NetType["HTTP"] = 2] = "HTTP";
    NetType[NetType["WEBSOCKET"] = 3] = "WEBSOCKET"; // websocket长链接
})(NetType = exports.NetType || (exports.NetType = {}));
/**
 * 网络失败代码
 */
var NetFailCode;
(function (NetFailCode) {
    NetFailCode[NetFailCode["NOT_INIT"] = 1001] = "NOT_INIT";
})(NetFailCode = exports.NetFailCode || (exports.NetFailCode = {}));
/**
 * 网络客户端基类
 * @author ituuz
 */
var NetHelper = /** @class */ (function () {
    function NetHelper() {
    }
    /**
     * 初始化网络链接
     * @param {NetType} type 链接类型
     * @param {string} addr 链接地址
     * @param {number} port 端口
     * @param {rsMap: Map<number, {new(): MessageBase}>} rsMap 协议映射关系表
     */
    NetHelper.init = function (type, addr, port, rsMap) {
        NetHelper._INIT = true;
        NetHelper._ADDR = addr;
        NetHelper._PORT = port;
        NetHelper._TYPE = type;
        NetHelper._RS_MAP = rsMap;
        // 初始化PB工具类
        PBUtils_1.default.init();
        // 实例化对应网络客户端
        switch (NetHelper._TYPE) {
            case NetType.HTTP:
                NetHelper._CLIENT = new HttpClient_1.default(addr, port);
                break;
            case NetType.LOCAL:
                NetHelper._CLIENT = new LocalClient_1.default(addr, port);
                break;
            case NetType.WEBSOCKET:
                NetHelper._CLIENT = new WebsocketClient_1.default(addr, port);
                break;
            default:
                LogUtil_1.default.error("[NetHelper] type: " + type + " is not exist!");
        }
    };
    /**
     * 链接
     * @param {() => void} succCB 连接成功回调
     * @param {(code: NetFailCode) => void} faultCB 链接失败回调
     */
    NetHelper.connect = function (succCB, faultCB) {
        if (!NetHelper._INIT) {
            LogUtil_1.default.warn("NetHelper is not init.");
            faultCB && faultCB(NetFailCode.NOT_INIT);
            return;
        }
        if (NetHelper._TYPE === NetType.HTTP) {
            succCB && succCB();
        }
        else if (NetHelper._TYPE === NetType.LOCAL) {
            // TODO local
        }
        else if (NetHelper._TYPE === NetType.WEBSOCKET) {
            // TODO ws
        }
    };
    /**
     * 发送消息
     * @param {MessageBase} msg 消息对象
     */
    NetHelper.sendRQ = function (msg) {
        NetHelper._CLIENT.sendReq(msg);
    };
    /**
     * 注册回调消息
     * @param {number} id 消息id
     * @param {(msg: MessageBase) => void} cb 回调
     */
    NetHelper.registerRS = function (id, cb) {
        // 注册
        NetHelper._CB_MAP.set(id, cb);
    };
    /**
     * 移除消息注册
     * @param {number} id 消息id
     */
    NetHelper.unregisterRS = function (id) {
        NetHelper._CB_MAP.delete(id);
    };
    /**
     * 派发消息
     * @param {number} pid 消息id
     * @param {MessageBase} msg 消息对象
     */
    NetHelper.dispatcher = function (pid, msg) {
        var cb = NetHelper._CB_MAP.get(pid);
        cb && cb(msg);
    };
    /**
     * 获取消息类
     * @param {number} pid 消息协议id
     */
    NetHelper.getMessageCls = function (pid) {
        return NetHelper._RS_MAP.get(pid);
    };
    // 是否初始化
    NetHelper._INIT = false;
    // 协议监听函数
    NetHelper._CB_MAP = new Map();
    return NetHelper;
}());
exports.NetHelper = NetHelper;

cc._RF.pop();