"use strict";
cc._RF.push(module, 'e8ad3XDDc1NG55/ELD8NnH4', 'NotificationManager');
// libs/core/mvc/manager/NotificationManager.ts

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 消息管理类
 * @author ituuz
 */
var ViewManager_1 = require("./ViewManager");
var NotificationManager = /** @class */ (function () {
    /**
     * @constructor
     * @private
     */
    function NotificationManager() {
    }
    /**
     * 单例获取类
     */
    NotificationManager.getInstance = function () {
        return this._instance;
    };
    /**
     * 发送消息通知, 框架使用，外部不得调用。
     * @param {string} noti 通知key值
     * @param {Object} body 消息传递的参数
     * @private
     */
    NotificationManager.prototype.__sendNotification__ = function (noti, body) {
        // pop view
        var popViewList = ViewManager_1.ViewManager.getInstance().popViewList;
        this.loopMap(popViewList, noti, body);
        // add layer view
        var layerViewList = ViewManager_1.ViewManager.getInstance().layerViewList;
        this.loopMap(layerViewList, noti, body);
        // scene
        var curScene = ViewManager_1.ViewManager.getInstance().curScene;
        this.loopMap([curScene], noti, body);
    };
    /**
     * 循环遍历map检索通知对象
     * @param {BaseMediator[]} list view mediator list
     * @param {string} noti 消息名称
     * @param {Object} body 消息传递的参数
     */
    NotificationManager.prototype.loopMap = function (list, noti, body) {
        for (var _i = 0, list_1 = list; _i < list_1.length; _i++) {
            var med = list_1[_i];
            var notiMap = med["_notiMap"];
            notiMap.forEach(function (value, key) {
                if (key === noti) {
                    value.cb.call(value.target, body);
                }
            }, this);
        }
    };
    // 实例
    NotificationManager._instance = new NotificationManager();
    return NotificationManager;
}());
exports.default = NotificationManager;

cc._RF.pop();