"use strict";
cc._RF.push(module, '1bba1j2GWhLLa3XVIS37ENx', 'SyncMacroCommand');
// libs/core/mvc/command/SyncMacroCommand.ts

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 同步组合宏命令基类
 * 该组合宏中的子命令是同步执行的，会按照添加的顺序同步执行。
 * @author ituuz
 */
var MacroCommand_1 = require("./MacroCommand");
var SyncMacroCommand = /** @class */ (function (_super) {
    __extends(SyncMacroCommand, _super);
    function SyncMacroCommand() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return SyncMacroCommand;
}(MacroCommand_1.default));
exports.default = SyncMacroCommand;

cc._RF.pop();