"use strict";
cc._RF.push(module, '23520SO8OhLPod2mFG0/mM6', 'SingleBase');
// libs/core/base/SingleBase.ts

Object.defineProperty(exports, "__esModule", { value: true });
var SingleBase = /** @class */ (function () {
    function SingleBase() {
    }
    return SingleBase;
}());
exports.default = SingleBase;

cc._RF.pop();