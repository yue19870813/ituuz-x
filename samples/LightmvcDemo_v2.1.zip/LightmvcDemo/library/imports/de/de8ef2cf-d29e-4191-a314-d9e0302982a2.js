"use strict";
cc._RF.push(module, 'de8efLP0p5BkaMU2eAwKYKi', 'LoadPopViewsCmd');
// libs/mvc_ex/command/LoadPopViewsCmd.ts

Object.defineProperty(exports, "__esModule", { value: true });
var SimpleCommand_1 = require("../../core/mvc/command/SimpleCommand");
var Facade_1 = require("../../core/mvc/Facade");
var JSUtil_1 = require("../../core/util/JSUtil");
/**
 * 根据配置加载场景或者view的命令。
 * @author ituuz
 */
var LoadPopViewsCmd = /** @class */ (function (_super) {
    __extends(LoadPopViewsCmd, _super);
    function LoadPopViewsCmd() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    LoadPopViewsCmd.prototype.undo = function (body) {
        throw new Error("Method not implemented.");
    };
    LoadPopViewsCmd.prototype.execute = function (body) {
        // 增加参数传递逻辑
        this.loadViews([body.mvc], body.data, body.parent, body.useCache);
    };
    /**
     * 根据配置数据加载view逻辑
     * @param {MVC_struct[]} views view配置
     * @param {any} data 自定义透传参数 可选
     * @param {cc.Node} parent 父节点 可选
     * @param {boolean} useCache 是否复用已存在的view 可选
     */
    LoadPopViewsCmd.prototype.loadViews = function (views, data, parent, useCache) {
        var _this = this;
        if (data === void 0) { data = null; }
        if (parent === void 0) { parent = null; }
        if (useCache === void 0) { useCache = false; }
        if (views && views.length > 0) {
            var _loop_1 = function (mvcObj) {
                var viewModule = null;
                JSUtil_1.default.importCls(mvcObj.viewClass).then(function (module) {
                    viewModule = module;
                    return JSUtil_1.default.importCls(mvcObj.medClass);
                }).then(function (medModule) {
                    Facade_1.Facade.getInstance().popView(medModule, viewModule, data, function (view) {
                        if (parent) {
                            view.node.parent = parent;
                        }
                        // 加载完成后的回调,递归加载childern
                        if (mvcObj.children && mvcObj.children.length > 0) {
                            _this.loadViews(mvcObj.children, null);
                        }
                    }, useCache);
                });
            };
            // 遍历节点数组创建layer
            for (var _i = 0, views_1 = views; _i < views_1.length; _i++) {
                var mvcObj = views_1[_i];
                _loop_1(mvcObj);
            }
        }
    };
    return LoadPopViewsCmd;
}(SimpleCommand_1.default));
exports.default = LoadPopViewsCmd;

cc._RF.pop();