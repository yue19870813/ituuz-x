"use strict";
cc._RF.push(module, 'a04ceeO+xdJ67VdOKiuzikn', 'TextLoader');
// libs/core/load/loader/base/TextLoader.ts

Object.defineProperty(exports, "__esModule", { value: true });
var BaseLoader_1 = require("./BaseLoader");
var TextLoader = /** @class */ (function (_super) {
    __extends(TextLoader, _super);
    function TextLoader() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    TextLoader.prototype.loadNetRes = function (path, type, callback) {
        // TODO 加载网络文本资源
        throw new Error("TextLoader loadNetRes method not implemented.");
    };
    TextLoader.prototype.loadRemoteRes = function (path, type, callback) {
        // TODO 加载远程待下载文本资源
        throw new Error("TextLoader loadRemoteRes method not implemented.");
    };
    TextLoader.prototype.loadLocalRes = function (path, type, callback) {
        cc.loader.loadRes(path, type, callback);
    };
    return TextLoader;
}(BaseLoader_1.default));
exports.default = TextLoader;

cc._RF.pop();