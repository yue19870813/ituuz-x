"use strict";
cc._RF.push(module, '9de58gq9N9J2rVTxAO2LbOk', 'LocalClient');
// libs/extension/net/LocalClient.ts

Object.defineProperty(exports, "__esModule", { value: true });
var NetClientBase_1 = require("./NetClientBase");
/**
 * LocalClient本地存储
 * @author ituuz
 */
var LocalClient = /** @class */ (function (_super) {
    __extends(LocalClient, _super);
    function LocalClient() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    LocalClient.prototype.sendReq = function (msg) {
        throw new Error("Method not implemented.");
    };
    return LocalClient;
}(NetClientBase_1.default));
exports.default = LocalClient;

cc._RF.pop();