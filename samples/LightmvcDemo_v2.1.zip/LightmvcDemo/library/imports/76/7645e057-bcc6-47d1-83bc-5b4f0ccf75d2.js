"use strict";
cc._RF.push(module, '7645eBXvMZH0YO8W08Mz3XS', 'UIUtils');
// libs/core/util/UIUtils.ts

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * UIUtils:解析UI节点工具类
 * @author ituuz
 */
var UIUtils = /** @class */ (function () {
    function UIUtils() {
    }
    /***
     * 生成子节点的唯一标识快捷访问
     * @param node
     * @param map
     */
    UIUtils.createSubNodeMap = function (node, map) {
        var children = node.children;
        if (!children) {
            return;
        }
        for (var t = 0, len = children.length; t < len; ++t) {
            var subChild = children[t];
            map.set(subChild.name, subChild);
            UIUtils.createSubNodeMap(subChild, map);
        }
    };
    /**
     * 返回当前节点所有节点,一唯一标识存在
     * @param node 父节点
     * @return {Object} 所有子节点的映射map
     */
    UIUtils.seekAllSubView = function (node) {
        var map = new Map();
        UIUtils.createSubNodeMap(node, map);
        return new UIContainer(map);
    };
    return UIUtils;
}());
exports.default = UIUtils;
var UIContainer = /** @class */ (function () {
    function UIContainer(nodesMap) {
        this._uiNodesMap = nodesMap;
    }
    UIContainer.prototype.setTarget = function (t) {
        this._target = t;
    };
    /**
     * 根据节点名字获取节点
     * @param {string}name 节点名字
     * @return {cc.Node}
     */
    UIContainer.prototype.getNode = function (name) {
        return this._uiNodesMap.get(name);
    };
    /**
     * 根据节点名字和组件类型获取组件对象
     * @param {string}name 节点名字
     * @param {{prototype: cc.Component}}com 组建类型
     * @return {cc.Component}
     */
    UIContainer.prototype.getComponent = function (name, com) {
        var node = this._uiNodesMap.get(name);
        if (node) {
            return node.getComponent(com);
        }
        return null;
    };
    /**
     * 发送点击事件
     * @param {cc.Node | string} node 事件节点
     * @param {string} event 事件名称
     * @param {any} param 事件参数（可选）
     */
    UIContainer.prototype.addClickEvent = function (node, event, param, target) {
        var _this = this;
        if (node) {
            var tempNode = null;
            if (typeof node === "string") {
                tempNode = this.getNode(node);
            }
            else {
                tempNode = node;
            }
            tempNode.on(cc.Node.EventType.TOUCH_END, function () {
                _this._target.sendEvent(event, param);
            }, target);
        }
    };
    return UIContainer;
}());
exports.UIContainer = UIContainer;
// 将接口导出
// tslint:disable-next-line: no-unused-expression
window.it || (window.it = {});
window.it.UIUtils = UIUtils;

cc._RF.pop();