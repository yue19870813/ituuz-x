"use strict";
cc._RF.push(module, '65d32mLwdlASrkuv1PtjKrE', 'SecondSceneMediator');
// script/view/SecondSceneMediator.ts

Object.defineProperty(exports, "__esModule", { value: true });
var GameMediator_1 = require("../../libs/mvc_ex/base/GameMediator");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SecondSceneMediator = /** @class */ (function (_super) {
    __extends(SecondSceneMediator, _super);
    function SecondSceneMediator() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SecondSceneMediator.prototype.init = function (data) {
        console.log("打开场景SecondSceneMediator");
    };
    SecondSceneMediator.prototype.viewDidAppear = function () {
        // 打开第二个UI
        // this.addLayer(SecondMediator, SecondView, 1);
    };
    SecondSceneMediator.prototype.destroy = function () {
    };
    SecondSceneMediator = __decorate([
        ccclass
    ], SecondSceneMediator);
    return SecondSceneMediator;
}(GameMediator_1.default));
exports.default = SecondSceneMediator;

cc._RF.pop();