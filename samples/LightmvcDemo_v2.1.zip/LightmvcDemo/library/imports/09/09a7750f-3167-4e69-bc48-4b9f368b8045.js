"use strict";
cc._RF.push(module, '09a77UPMWdOabxIS582i4BF', 'GameContent');
// libs/core/mvc/base/GameContent.ts

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 游戏场景数据
 * @author ituuz
 */
var GameContent = /** @class */ (function () {
    function GameContent() {
        /** 自定义数据 */
        this.data = {};
    }
    return GameContent;
}());
exports.default = GameContent;

cc._RF.pop();