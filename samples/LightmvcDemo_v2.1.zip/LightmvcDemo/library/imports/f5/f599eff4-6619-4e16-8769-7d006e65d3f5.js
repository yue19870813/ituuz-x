"use strict";
cc._RF.push(module, 'f599e/0ZhlOFodpfQBuZdP1', 'MessageBase');
// libs/extension/net/MessageBase.ts

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 消息协议基类，声明的pb文件会生成对应的message类文件供业务使用。
 * @author ituuz
 */
var MessageBase = /** @class */ (function () {
    function MessageBase() {
    }
    MessageBase.create = function (cb) {
        return null;
    };
    /**
     * 将消息体转成ArrayBuff
     */
    MessageBase.prototype.toBuffer = function () {
        return null;
    };
    /**
     * 将ArrayBuff转成消息对象
     * @param buffer
     */
    MessageBase.prototype.parseBuffer = function (buffer) {
    };
    Object.defineProperty(MessageBase.prototype, "PID", {
        // 返回协议pid
        get: function () {
            return -1;
        },
        enumerable: true,
        configurable: true
    });
    return MessageBase;
}());
exports.default = MessageBase;

cc._RF.pop();