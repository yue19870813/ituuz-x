"use strict";
cc._RF.push(module, 'f0869PNJZ9Aw7Q0rEW2PDMF', 'NetClientBase');
// libs/extension/net/NetClientBase.ts

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 网络客户端基类
 * @author ituuz
 */
var NetClientBase = /** @class */ (function () {
    function NetClientBase(addr, port) {
        this.addr = addr;
        this.port = port;
    }
    return NetClientBase;
}());
exports.default = NetClientBase;

cc._RF.pop();