"use strict";
cc._RF.push(module, '6244cdoG5lKLKIxIDDTGdFA', 'DefaultScene');
// script/view/DefaultScene.ts

Object.defineProperty(exports, "__esModule", { value: true });
var GameScene_1 = require("../../libs/mvc_ex/base/GameScene");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var DefaultScene = /** @class */ (function (_super) {
    __extends(DefaultScene, _super);
    function DefaultScene() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    DefaultScene = __decorate([
        ccclass
    ], DefaultScene);
    return DefaultScene;
}(GameScene_1.default));
exports.default = DefaultScene;

cc._RF.pop();