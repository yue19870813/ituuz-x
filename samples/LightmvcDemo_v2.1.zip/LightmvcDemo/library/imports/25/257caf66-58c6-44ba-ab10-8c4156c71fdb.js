"use strict";
cc._RF.push(module, '257ca9mWMZEuqsQjEFWxx/b', 'GameModel');
// libs/mvc_ex/base/GameModel.ts

Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 数据Model基类
 * @author ituuz
 * @description 封装了数据初始化，消息接发等基本业务逻辑
 */
var BaseModel_1 = require("../../core/mvc/base/BaseModel");
var NetHelper_1 = require("../../extension/net/NetHelper");
var GameModel = /** @class */ (function (_super) {
    __extends(GameModel, _super);
    function GameModel() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /** ❗️禁止重写和调用，除非你知道自己在干什么 */
    GameModel.prototype.__init__ = function () {
        this.registerPB();
        this.init();
    };
    GameModel.prototype.init = function () {
    };
    // 注册pb
    GameModel.prototype.registerPB = function () {
        var pbs = this.protobuf();
        for (var _i = 0, pbs_1 = pbs; _i < pbs_1.length; _i++) {
            var pb = pbs_1[_i];
            NetHelper_1.NetHelper.registerRS(pb.pid, pb.cb);
        }
    };
    /**
     * 添加新回调消息
     * @param {number} id 消息id
     * @param {(msg: MessageBase) => void} cb 回调
     */
    GameModel.prototype.addRS = function (pid, cb) {
        NetHelper_1.NetHelper.registerRS(pid, cb);
    };
    /**
     * 移除消息注册
     * @param {number} id 消息id
     */
    GameModel.prototype.removeRS = function (pid) {
        NetHelper_1.NetHelper.unregisterRS(pid);
    };
    /**
     * 发送消息
     * @param {MessageBase} msg 消息对象
     */
    GameModel.prototype.sendRQ = function (msg) {
        NetHelper_1.NetHelper.sendRQ(msg);
    };
    /**
     * 配置注册的PB消息
     */
    GameModel.prototype.protobuf = function () {
        return [];
    };
    /** 清理model类 */
    GameModel.prototype.clear = function () {
    };
    return GameModel;
}(BaseModel_1.default));
exports.default = GameModel;

cc._RF.pop();