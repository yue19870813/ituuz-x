"use strict";
cc._RF.push(module, '4ac45DZ+vVGHZjDX77XlMB6', 'ITAtlas');
// libs/core/load/atlas/ITAtlas.ts

Object.defineProperty(exports, "__esModule", { value: true });
var LogUtil_1 = require("../../util/LogUtil");
/**
 * 单个UI界面的Atlas对象，负责管理该界面的图集资源；
 * @author ituuz
 */
var ITUIAtlas = /** @class */ (function () {
    function ITUIAtlas() {
        /** 该UI使用的图集map集合 */
        this._atlasMap = new Map();
    }
    /**
     * 添加该UI需要加载的atlas资源
     * @param {string} key 资源key值，默认就是图集的路径。
     * @param {ITAtlas} atlas 图集对象
     */
    ITUIAtlas.prototype.addAtlas = function (key, atlas) {
        this._atlasMap.set(key, atlas);
    };
    /**
     * 为sprite设置纹理
     * @param {cc.Sprite} sprite sprite对象
     * @param {string} name 纹理名称
     * @param {string} key 图集key值，如果不传key，则默认使用该UI的第一个图集来设置；
     */
    ITUIAtlas.prototype.setSpriteFrame = function (sprite, name, key) {
        if (key) {
            var atlas = this._atlasMap.get(key);
            if (atlas) {
                atlas.setSpriteFrame(sprite, name);
            }
        }
        else {
            var keys = this._atlasMap.keys();
            var keyList = Array.from(keys);
            for (var _i = 0, keyList_1 = keyList; _i < keyList_1.length; _i++) {
                var k = keyList_1[_i];
                var atlas = this._atlasMap.get(k);
                if (atlas) {
                    // 如果不传key，则默认使用该UI的一个图集来设置；
                    atlas.setSpriteFrame(sprite, name);
                    break;
                }
            }
        }
    };
    Object.defineProperty(ITUIAtlas.prototype, "atlasMap", {
        get: function () {
            return this._atlasMap;
        },
        enumerable: true,
        configurable: true
    });
    return ITUIAtlas;
}());
exports.default = ITUIAtlas;
/**
 * 单个图集对象
 * @author ituuz
 */
var ITAtlas = /** @class */ (function () {
    function ITAtlas(url) {
        /** 该图集是否加载完成 */
        this._loaded = false;
        /** 加载的错误信息 */
        this._loadError = null;
        /** 待显示的sprite等待管线 */
        this._spritePipe = [];
        this._url = url;
    }
    /**
     * 通过缓存设置sprite纹理
     * @param {string} name 纹理名称
     * @param {(err, frame) => void} callback 纹理设置完成回调
     */
    ITAtlas.prototype.cacheLoad = function (name, callback) {
        if (this._loadError) {
            LogUtil_1.default.warn("atlas [" + this._url + "] load failed");
        }
        else {
            var frame = this._atlas.getSpriteFrame(name);
            if (frame) {
                callback && callback(null, frame);
            }
            else {
                LogUtil_1.default.warn("spriteframe [" + name + "] not found in atlas [" + this._url + "]");
            }
        }
    };
    /**
     * 从缓存或者异步加载纹理图集
     * @param {string} name 图集名称
     * @param {callback: (err, frame) => void} callback 加载完成回调
     */
    ITAtlas.prototype.loadSpriteFrame = function (name, callback) {
        if (this._loaded) {
            this.cacheLoad(name, callback);
        }
        else {
            this._spritePipe.push({ name: name, callback: callback });
        }
    };
    /**
     * 为sprite设置纹理
     * @param {cc.Sprite} sprite sprite组件对象
     * @param {string} name 纹理名称
     */
    ITAtlas.prototype.setSpriteFrame = function (sprite, name) {
        this.loadSpriteFrame(name, function (err, frame) {
            if (!err) {
                if (sprite) {
                    sprite.spriteFrame = frame;
                }
                else {
                    LogUtil_1.default.log("[ITAtlas] sprite is null!");
                }
            }
            else {
                LogUtil_1.default.warn(err);
                LogUtil_1.default.log("[ITAtlas] can't find frame name: " + name);
            }
        });
    };
    /**
     * 图集加载完成调用的接口，此处为私有接口，在AtlasMananger中要隐式调用，反射；
     * @param {any} err 加载错误信息
     * @param {cc.SpriteAtlas} atlas 图集
     */
    ITAtlas.prototype.atlasLoaded = function (err, atlas) {
        this._atlas = atlas;
        this._loadError = err;
        this._loaded = true;
        // 设置管线中的sprite
        for (var _i = 0, _a = this._spritePipe; _i < _a.length; _i++) {
            var pipe = _a[_i];
            this.cacheLoad(pipe.name, pipe.callback);
        }
        // 清空管线
        this._spritePipe = [];
    };
    return ITAtlas;
}());
exports.ITAtlas = ITAtlas;

cc._RF.pop();