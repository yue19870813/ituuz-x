"use strict";
cc._RF.push(module, '6a7fcS5RnlFNobV9qQw6C0u', 'PBUtils');
// libs/extension/net/PBUtils.ts

Object.defineProperty(exports, "__esModule", { value: true });
var LogUtil_1 = require("../../core/util/LogUtil");
/**
 * 处理pb相关接口工具类
 * @author ituuz
 */
var PBUtils = /** @class */ (function () {
    function PBUtils() {
    }
    /** 工具初始化接口 */
    PBUtils.init = function () {
        PBUtils.protobufjs = require("protobufjs");
        // 此方法是将ProtoBuf.Util.fetch函数替换成cc.loader.loadRes函数，以解决在微信小游戏中不能使用XHR的问题
        PBUtils.protobufjs.loadProtoFile = function (filename, callback) {
            cc.loader.loadRes(filename, cc.JsonAsset, function (err, json) {
                if (err) {
                    LogUtil_1.default.warn(filename + "is not exist!");
                    return;
                }
                var root = PBUtils.protobufjs.Root.fromJSON(json.json);
                callback(err, root);
            });
        };
    };
    /** 加载指定的pb文件 */
    PBUtils.loadFile = function (filename, callback) {
        PBUtils.protobufjs.loadProtoFile(filename, callback);
    };
    return PBUtils;
}());
exports.default = PBUtils;

cc._RF.pop();