"use strict";
cc._RF.push(module, '41a99M+mMFOj4FoWjaTaGX6', 'BaseModel');
// libs/core/mvc/base/BaseModel.ts

Object.defineProperty(exports, "__esModule", { value: true });
var NotificationManager_1 = require("../manager/NotificationManager");
/**
 * 数据模型基类
 * init和clear接口需要子类重写
 * @author ituuz
 */
var BaseModel = /** @class */ (function () {
    function BaseModel() {
    }
    /** 禁止重写和调用，除非你知道自己在干什么 */
    BaseModel.prototype.__init__ = function () {
        this.init();
    };
    /**
     * 发送消息接口
     * @param {string} noti 消息名称
     * @param {Object} data 消息数据
     */
    BaseModel.prototype.sendNoti = function (noti, data) {
        NotificationManager_1.default.getInstance().__sendNotification__(noti, data);
    };
    return BaseModel;
}());
exports.default = BaseModel;

cc._RF.pop();