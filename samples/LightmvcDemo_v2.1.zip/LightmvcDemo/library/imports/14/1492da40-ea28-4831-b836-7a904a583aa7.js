"use strict";
cc._RF.push(module, '1492dpA6ihIMbg2epBKWDqn', 'PopBView');
// script/view/pop_b/PopBView.ts

Object.defineProperty(exports, "__esModule", { value: true });
var GameView_1 = require("../../../libs/mvc_ex/base/GameView");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var PopBView = /** @class */ (function (_super) {
    __extends(PopBView, _super);
    function PopBView() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    PopBView_1 = PopBView;
    PopBView.prototype.drawView = function (param) {
        var _this = this;
        var closeBtn = this.ui.getNode("close_button");
        closeBtn.on(cc.Node.EventType.TOUCH_END, function () {
            _this.closeView();
        }, this);
        var titleLabel = this.ui.getComponent("title_label", cc.Label);
        titleLabel.string = "传入的参数为：" + param;
        var runBtn = this.ui.getNode("run_btn");
        runBtn.on(cc.Node.EventType.TOUCH_END, function () {
            _this.sendEvent(PopBView_1.RUN_SECOND_SCENE);
        }, this);
    };
    PopBView.path = function () {
        return "prefabs/pop_b";
    };
    var PopBView_1;
    PopBView.RUN_SECOND_SCENE = "RUN_SECOND_SCENE";
    PopBView = PopBView_1 = __decorate([
        ccclass
    ], PopBView);
    return PopBView;
}(GameView_1.default));
exports.default = PopBView;

cc._RF.pop();