"use strict";
cc._RF.push(module, 'c86f9AAJFdAQIHDdoBOKuYq', 'PopBMediator');
// script/view/pop_b/PopBMediator.ts

Object.defineProperty(exports, "__esModule", { value: true });
var PopBView_1 = require("./PopBView");
var GameMediator_1 = require("../../../libs/mvc_ex/base/GameMediator");
var SceneCfg_1 = require("../../SceneCfg");
var PopBMediator = /** @class */ (function (_super) {
    __extends(PopBMediator, _super);
    function PopBMediator() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    PopBMediator.prototype.init = function (data) {
    };
    PopBMediator.prototype.viewDidAppear = function () {
        var _this = this;
        this.view.drawView("888");
        this.bindEvent(PopBView_1.default.RUN_SECOND_SCENE, function () {
            _this.gotoScene(SceneCfg_1.default.SECOND_SCENE);
        }, this);
    };
    PopBMediator.prototype.destroy = function () {
    };
    return PopBMediator;
}(GameMediator_1.default));
exports.default = PopBMediator;

cc._RF.pop();