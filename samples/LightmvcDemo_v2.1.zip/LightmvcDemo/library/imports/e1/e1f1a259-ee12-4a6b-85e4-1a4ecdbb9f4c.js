"use strict";
cc._RF.push(module, 'e1f1aJZ7hJKa4XkGk7Nu59M', 'GameComponent');
// libs/mvc_ex/base/GameComponent.ts

Object.defineProperty(exports, "__esModule", { value: true });
var CommandManager_1 = require("../../core/mvc/manager/CommandManager");
var NotificationManager_1 = require("../../core/mvc/manager/NotificationManager");
var Facade_1 = require("../../core/mvc/Facade");
var GameComponent = /** @class */ (function (_super) {
    __extends(GameComponent, _super);
    function GameComponent() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    /**
     * 发送命令接口
     * @param {{new (): BaseCommand}} cmd 命令类
     * @param {Object} data 命令参数
     */
    GameComponent.prototype.sendCmd = function (cmd, data) {
        CommandManager_1.default.getInstance().__executeCommand__(cmd, data);
    };
    /**
     * 发送消息通知
     * @param {string} noti 通知key值
     * @param {Object} body 消息传递的参数
     */
    GameComponent.prototype.sendNoti = function (noti, body) {
        NotificationManager_1.default.getInstance().__sendNotification__(noti, body);
    };
    /**
     * 获取model对象
     * @param {{new (): BaseModel}} model
     */
    GameComponent.prototype.getModel = function (model) {
        return Facade_1.Facade.getInstance().getModel(model);
    };
    return GameComponent;
}(cc.Component));
exports.default = GameComponent;

cc._RF.pop();