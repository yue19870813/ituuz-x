(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/view/first/FirstMediator.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'fd0a799MHVErr/anqO67FXP', 'FirstMediator', __filename);
// script/view/first/FirstMediator.ts

Object.defineProperty(exports, "__esModule", { value: true });
var GameMediator_1 = require("../../../libs/mvc_ex/base/GameMediator");
var SceneCfg_1 = require("../../SceneCfg");
var FirstView_1 = require("./FirstView");
var FirstMediator = /** @class */ (function (_super) {
    __extends(FirstMediator, _super);
    function FirstMediator() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    FirstMediator.prototype.init = function (data) {
        // 此时view还没有初始化
    };
    FirstMediator.prototype.viewDidAppear = function () {
        var _this = this;
        var myName = this.sceneContent.data.myName;
        // view 初始化后可对view进行操作
        this.view.setData(myName);
        this.bindEvent(FirstView_1.default.OPEN_A, function (str) {
            // 打开新界面，并且设置其父节点为：this.view.node
            // this.addView(ViewCfg.POP_A_VIEW, null, this.view.node);
            // 默认层级
            _this.addView(SceneCfg_1.ViewCfg.POP_A_VIEW);
        }, this);
        this.bindEvent(FirstView_1.default.OPEN_B, function (str) {
            // 打开界面B，并且设置第四个参数为true，意思是其节点复用，只会存在一个实例，而上面的界面B会存在多个实例
            _this.addView(SceneCfg_1.ViewCfg.POP_B_VIEW, null, null, true);
        }, this);
    };
    FirstMediator.prototype.destroy = function () {
    };
    return FirstMediator;
}(GameMediator_1.default));
exports.default = FirstMediator;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=FirstMediator.js.map
        