(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/view/first/TopMediator.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'fa743UR3KZDpZ/HtJi90fb8', 'TopMediator', __filename);
// script/view/first/TopMediator.ts

Object.defineProperty(exports, "__esModule", { value: true });
var GameMediator_1 = require("../../../libs/mvc_ex/base/GameMediator");
var TopMediator = /** @class */ (function (_super) {
    __extends(TopMediator, _super);
    function TopMediator() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return TopMediator;
}(GameMediator_1.default));
exports.default = TopMediator;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=TopMediator.js.map
        