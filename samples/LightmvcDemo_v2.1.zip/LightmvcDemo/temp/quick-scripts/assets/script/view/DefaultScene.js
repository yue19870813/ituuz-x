(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/view/DefaultScene.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '6244cdoG5lKLKIxIDDTGdFA', 'DefaultScene', __filename);
// script/view/DefaultScene.ts

Object.defineProperty(exports, "__esModule", { value: true });
var GameScene_1 = require("../../libs/mvc_ex/base/GameScene");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var DefaultScene = /** @class */ (function (_super) {
    __extends(DefaultScene, _super);
    function DefaultScene() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    DefaultScene = __decorate([
        ccclass
    ], DefaultScene);
    return DefaultScene;
}(GameScene_1.default));
exports.default = DefaultScene;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=DefaultScene.js.map
        