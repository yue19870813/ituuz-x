(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/view/SecondScene.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'bc098HlPh9Pm59pCnXMjEKJ', 'SecondScene', __filename);
// script/view/SecondScene.ts

Object.defineProperty(exports, "__esModule", { value: true });
var GameScene_1 = require("../../libs/mvc_ex/base/GameScene");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var SecondScene = /** @class */ (function (_super) {
    __extends(SecondScene, _super);
    function SecondScene() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SecondScene = __decorate([
        ccclass
    ], SecondScene);
    return SecondScene;
}(GameScene_1.default));
exports.default = SecondScene;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=SecondScene.js.map
        