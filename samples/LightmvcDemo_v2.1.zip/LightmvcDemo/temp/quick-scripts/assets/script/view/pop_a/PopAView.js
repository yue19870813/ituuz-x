(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/view/pop_a/PopAView.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '48e7847HmBFFbi2lI/pxieh', 'PopAView', __filename);
// script/view/pop_a/PopAView.ts

Object.defineProperty(exports, "__esModule", { value: true });
var GameView_1 = require("../../../libs/mvc_ex/base/GameView");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var PopAView = /** @class */ (function (_super) {
    __extends(PopAView, _super);
    function PopAView() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    PopAView_1 = PopAView;
    PopAView.prototype.drawView = function (param) {
        var _this = this;
        // 关闭按钮
        var closeBtn = this.ui.getNode("close_button");
        closeBtn.on(cc.Node.EventType.TOUCH_END, function () {
            _this.closeView();
        }, this);
        // this.ui.addClickEvent(closeBtn, cc.Node.EventType.TOUCH_END, "close");
        // this.ui.addClickEvent("close_button", cc.Node.EventType.TOUCH_END, "close");
        // 显示传入参数的label
        var titleLabel = this.ui.getComponent("title_label", cc.Label);
        titleLabel.string = "传入的参数为：" + param;
        // 修改等级按钮
        var okBtn = this.ui.getNode("ok_btn");
        okBtn.on(cc.Node.EventType.TOUCH_END, function () {
            // 获取输入框填写的经验
            var expEditBox = _this.ui.getComponent("exp_edit_box", cc.EditBox);
            _this.sendEvent(PopAView_1.UPDATE_LEVEL, expEditBox.string);
        }, this);
    };
    PopAView.prototype.setLevelDisplay = function (lv) {
        var levelLabel = this.ui.getComponent("des_label", cc.Label);
        levelLabel.string = "当前等级为：" + lv;
    };
    PopAView.path = function () {
        return "prefabs/pop_a";
    };
    var PopAView_1;
    PopAView.UPDATE_LEVEL = "UPDATE_LEVEL";
    PopAView = PopAView_1 = __decorate([
        ccclass
    ], PopAView);
    return PopAView;
}(GameView_1.default));
exports.default = PopAView;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=PopAView.js.map
        