(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/script/NativeScene.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '4acc86QzR9J7ql/6au8TXuT', 'NativeScene', __filename);
// script/NativeScene.ts

Object.defineProperty(exports, "__esModule", { value: true });
var PlayerModel_1 = require("./model/PlayerModel");
var SceneCfg_1 = require("./SceneCfg");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NativeScene = /** @class */ (function (_super) {
    __extends(NativeScene, _super);
    function NativeScene() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.label = null;
        _this.text = 'hello';
        return _this;
    }
    NativeScene.prototype.start = function () {
        this.label.string = "first scene is a native scene.";
        // initialize mvc framework
        // Facade.getInstance().init(false, cc.size(1080, 2048), false, true);
        // 初始化框架
        it.Framework.start(SceneCfg_1.default.DEFAULT_SCENE, [
            PlayerModel_1.default
        ], false, cc.size(1080, 2048), false, true);
    };
    // 点击切换场景
    NativeScene.prototype.onClick = function () {
        // run first mvc scene
        // Facade.getInstance().runScene(DefaultSceneMediator, DefaultScene, "测试参数999");
    };
    __decorate([
        property(cc.Label)
    ], NativeScene.prototype, "label", void 0);
    __decorate([
        property
    ], NativeScene.prototype, "text", void 0);
    NativeScene = __decorate([
        ccclass
    ], NativeScene);
    return NativeScene;
}(cc.Component));
exports.default = NativeScene;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=NativeScene.js.map
        