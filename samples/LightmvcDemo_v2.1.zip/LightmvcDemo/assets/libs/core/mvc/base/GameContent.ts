/**
 * 游戏场景数据
 * @author ituuz
 */
export default class GameContent {
    /** 自定义数据 */
    public data: any = {};
}
