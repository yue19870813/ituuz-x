/**
 * 命令基类
 * @author ituuz
 */

export default class BaseCommand {

}
