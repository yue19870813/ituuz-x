
export default class SingleBase {

}