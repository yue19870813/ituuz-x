import BaseScene from "../../core/mvc/base/BaseScene";

export default class GameScene extends BaseScene {


}
