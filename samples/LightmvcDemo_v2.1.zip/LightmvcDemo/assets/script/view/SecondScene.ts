import GameScene from "../../libs/mvc_ex/base/GameScene";

const {ccclass, property} = cc._decorator;

@ccclass
export default class SecondScene extends GameScene {

   
}
